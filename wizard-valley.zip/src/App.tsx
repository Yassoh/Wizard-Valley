/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { GameSaveProvider } from './context/GameSaveContext';
import { StartMenuView } from './components/StartMenuView';
import { RoomSettingsView } from './components/RoomSettingsView';
import { ArcaneForgeView } from './components/ArcaneForgeView';
import { WeaponLoadoutsView } from './components/WeaponLoadoutsView';
import { WeaponCollectionView } from './components/WeaponCollectionView';
import { ArenaMatchView } from './components/ArenaMatchView';
import { SaveBackupModal } from './components/SaveBackupModal';
import { CharacterCustomizerModal } from './components/CharacterCustomizerModal';
import { RoomSettings, RoomPlayer } from './types/game';

export type GameScreen = 
  | 'start_menu'
  | 'room_settings' 
  | 'forge' 
  | 'loadouts' 
  | 'collection' 
  | 'arena';

const MainCitadelApp: React.FC = () => {
  // Starts directly on the Start Menu screen
  const [currentScreen, setCurrentScreen] = useState<GameScreen>('start_menu');
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
  const [isAtelierOpen, setIsAtelierOpen] = useState(false);
  
  // Match launch settings state
  const [activeMatchSettings, setActiveMatchSettings] = useState<RoomSettings | undefined>(undefined);
  const [activeMatchPlayers, setActiveMatchPlayers] = useState<RoomPlayer[]>([]);

  const handleStartMatch = (settings: RoomSettings, players: RoomPlayer[]) => {
    setActiveMatchSettings(settings);
    setActiveMatchPlayers(players);
    setCurrentScreen('arena');
  };

  const handleExitMatch = () => {
    setCurrentScreen('room_settings');
  };

  const handleBackToMenu = () => {
    setCurrentScreen('start_menu');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#050811] text-slate-100 selection:bg-amber-500/30 selection:text-amber-200">
      {/* Note: TopBar removed as requested ("remov e that top part") */}

      {/* Main View Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-3 sm:px-6 py-4 sm:py-6">
        {currentScreen === 'start_menu' && (
          <StartMenuView
            onSelectScreen={setCurrentScreen}
            onOpenSaveModal={() => setIsSaveModalOpen(true)}
            onOpenAtelierModal={() => setIsAtelierOpen(true)}
          />
        )}

        {currentScreen === 'room_settings' && (
          <RoomSettingsView 
            onStartMatch={handleStartMatch}
            onBackToMenu={handleBackToMenu}
          />
        )}

        {currentScreen === 'forge' && (
          <ArcaneForgeView 
            onBackToMenu={handleBackToMenu}
          />
        )}

        {currentScreen === 'loadouts' && (
          <WeaponLoadoutsView 
            onBackToMenu={handleBackToMenu}
          />
        )}

        {currentScreen === 'collection' && (
          <WeaponCollectionView 
            onBackToMenu={handleBackToMenu}
          />
        )}

        {currentScreen === 'arena' && (
          <ArenaMatchView
            initialSettings={activeMatchSettings}
            players={activeMatchPlayers}
            onExitToLobby={handleExitMatch}
          />
        )}
      </main>

      {/* Save & Backup Modal */}
      <SaveBackupModal
        isOpen={isSaveModalOpen}
        onClose={() => setIsSaveModalOpen(false)}
      />

      {/* Character Atelier Customizer Modal */}
      <CharacterCustomizerModal
        isOpen={isAtelierOpen}
        onClose={() => setIsAtelierOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <GameSaveProvider>
      <MainCitadelApp />
    </GameSaveProvider>
  );
}
