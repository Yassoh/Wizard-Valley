import React, { useState } from 'react';
import { 
  Swords, 
  Play, 
  Hammer, 
  Layers, 
  BookOpen, 
  Sparkles, 
  Save, 
  Volume2, 
  VolumeX, 
  Shield, 
  Users, 
  Zap, 
  Flame, 
  ChevronRight,
  Crown
} from 'lucide-react';
import { useGameSave } from '../context/GameSaveContext';
import { sounds } from '../utils/audio';

interface StartMenuViewProps {
  onSelectScreen: (screen: 'room_settings' | 'forge' | 'loadouts' | 'collection' | 'arena') => void;
  onOpenSaveModal: () => void;
  onOpenAtelierModal: () => void;
}

export const StartMenuView: React.FC<StartMenuViewProps> = ({
  onSelectScreen,
  onOpenSaveModal,
  onOpenAtelierModal,
}) => {
  const { saveData, equippedWeaponData, cheatAddMaterials } = useGameSave();
  const [sfxOn, setSfxOn] = useState(true);
  const [cheatToast, setCheatToast] = useState(false);

  const toggleSound = () => {
    sounds.enabled = !sfxOn;
    setSfxOn(!sfxOn);
    if (!sfxOn) sounds.playClick();
  };

  const handleCheat = () => {
    cheatAddMaterials();
    setCheatToast(true);
    setTimeout(() => setCheatToast(false), 2500);
  };

  const character = saveData.character;
  const equippedStaff = equippedWeaponData?.name || 'Apprentice Staff';
  const staffLevel = saveData.weapons.owned[saveData.weapons.equippedId]?.upgradeLevel ?? 0;

  return (
    <div className="relative min-h-[90vh] flex flex-col justify-between items-center py-6 px-4">
      {/* Background Ambience */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden flex items-center justify-center">
        <div className="w-[600px] h-[600px] bg-purple-600/10 rounded-full blur-3xl animate-pulse" />
        <div className="w-[450px] h-[450px] bg-amber-500/10 rounded-full blur-3xl -top-20" />
      </div>

      {/* Top Header Utilities */}
      <div className="w-full max-w-5xl flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-600 via-purple-600 to-cyan-500 p-0.5 shadow-lg">
            <div className="w-full h-full bg-slate-950 rounded-[6px] flex items-center justify-center">
              <Shield className="w-4 h-4 text-amber-400" />
            </div>
          </div>
          <span className="font-cinzel text-sm font-bold tracking-widest text-slate-400 uppercase">
            Wizard Valley Studio
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Quick Sound Toggle */}
          <button
            onClick={toggleSound}
            aria-label={sfxOn ? "Mute audio" : "Enable audio"}
            className="p-2 text-slate-400 hover:text-slate-100 hover:bg-slate-900/80 rounded-lg border border-slate-800 transition-colors cursor-pointer"
          >
            {sfxOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Quick Save Manager */}
          <button
            onClick={() => {
              onOpenSaveModal();
              sounds.playClick();
            }}
            className="px-3 py-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-900/80 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <Save className="w-3.5 h-3.5 text-amber-400" />
            <span>Save & Backup</span>
          </button>
        </div>
      </div>

      {/* Centerpiece: Title & Character Spotlight */}
      <div className="w-full max-w-4xl flex flex-col items-center text-center my-auto z-10 pt-4 pb-8 space-y-6">
        {/* Title */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold tracking-widest uppercase">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Multiplayer Spellcraft & Arcane Forge</span>
          </div>
          <h1 className="text-4xl sm:text-6xl md:text-7xl font-black font-cinzel tracking-wider text-transparent bg-clip-text bg-gradient-to-b from-amber-100 via-amber-300 to-amber-600 drop-shadow-md">
            WIZARD VALLEY
          </h1>
          <p className="text-sm sm:text-base text-slate-400 max-w-xl mx-auto font-light">
            Master the 8 primordial elements, customize host room rules, forge mythical magic staffs, and duel in real-time combat.
          </p>
        </div>

        {/* Wizard Character Showcase Card */}
        <div className="relative group bg-slate-950/80 border border-slate-800/80 hover:border-purple-500/50 p-5 rounded-2xl shadow-2xl backdrop-blur-md max-w-md w-full transition-all">
          <div className="flex items-center gap-4 text-left">
            {/* Animated Wizard Avatar Icon */}
            <div 
              className="relative w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 border border-slate-700/80 overflow-hidden shadow-inner"
              style={{
                backgroundColor: character.robeColor || '#1e1b4b',
                boxShadow: `0 0 20px ${character.auraColor || '#a855f7'}40`,
              }}
            >
              {/* Wizard Hat Visual */}
              <div className="text-2xl select-none">🧙‍♂️</div>
              {/* Aura Ring */}
              <div 
                className="absolute inset-0 rounded-2xl border-2 pointer-events-none animate-pulse"
                style={{ borderColor: character.auraColor || '#c084fc' }}
              />
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-100 font-cinzel text-base truncate">
                  {character.name}
                </h3>
                <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-800 text-cyan-300 font-semibold tabular-nums">
                  Lv. {character.level}
                </span>
              </div>
              <div className="text-xs text-slate-400 mt-0.5 truncate">
                {character.title}
              </div>
              <div className="flex items-center gap-3 mt-2 text-xs text-slate-300">
                <span className="text-amber-400 font-medium">
                  💰 {saveData.economy.coins.toLocaleString()} Gold
                </span>
                <span className="text-slate-600">·</span>
                <span className="text-purple-300 truncate">
                  🪄 {equippedStaff} (Lv. {staffLevel})
                </span>
              </div>
            </div>
          </div>

          {/* Quick Customize button */}
          <button
            onClick={() => {
              onOpenAtelierModal();
              sounds.playClick();
            }}
            className="w-full mt-3 py-1.5 px-3 rounded-lg bg-slate-900 hover:bg-purple-950/50 border border-slate-800 hover:border-purple-700/60 text-xs font-semibold text-purple-300 hover:text-purple-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Sparkles className="w-3 h-3 text-purple-400" />
            <span>Customize Wizard Appearance</span>
          </button>
        </div>

        {/* Primary Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 max-w-2xl w-full pt-2">
          {/* Option 1: Multiplayer Room Settings (Primary Request #58-#62) */}
          <button
            onClick={() => {
              onSelectScreen('room_settings');
              sounds.playClick();
            }}
            className="sm:col-span-2 group relative p-4 rounded-xl bg-gradient-to-r from-amber-600/90 via-amber-500/90 to-yellow-600/90 hover:from-amber-500 hover:to-yellow-500 text-slate-950 font-bold shadow-lg shadow-amber-500/20 hover:shadow-amber-500/30 transition-all cursor-pointer flex items-center justify-between"
          >
            <div className="flex items-center gap-3.5 text-left">
              <div className="w-11 h-11 rounded-lg bg-slate-950/20 flex items-center justify-center shrink-0">
                <Crown className="w-6 h-6 text-slate-950" />
              </div>
              <div>
                <div className="font-cinzel text-lg font-extrabold tracking-wide flex items-center gap-2">
                  <span>MULTIPLAYER ROOM SETTINGS</span>
                  <span className="text-[10px] uppercase font-sans tracking-widest bg-slate-950 text-amber-300 px-2 py-0.5 rounded-full font-bold">
                    Host Console
                  </span>
                </div>
                <div className="text-xs font-medium text-slate-900/80">
                  Custom presets, map hazard rules, player management & match launch
                </div>
              </div>
            </div>
            <ChevronRight className="w-6 h-6 group-hover:translate-x-1 transition-transform shrink-0" />
          </button>

          {/* Option 2: Quick Arena Combat */}
          <button
            onClick={() => {
              onSelectScreen('arena');
              sounds.playClick();
            }}
            className="group p-4 rounded-xl bg-slate-950/90 hover:bg-slate-900 border border-cyan-800/80 hover:border-cyan-500 text-left transition-all shadow-md cursor-pointer flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-cyan-950 border border-cyan-700/60 flex items-center justify-center shrink-0">
                <Play className="w-5 h-5 text-cyan-400 fill-current" />
              </div>
              <div>
                <div className="font-cinzel text-sm font-bold text-cyan-200">
                  ARENA COMBAT
                </div>
                <div className="text-xs text-slate-400">
                  60 FPS 8-Element Live Battle
                </div>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-cyan-400 group-hover:translate-x-1 transition-transform" />
          </button>

          {/* Option 3: Arcane Forge */}
          <button
            onClick={() => {
              onSelectScreen('forge');
              sounds.playClick();
            }}
            className="group p-4 rounded-xl bg-slate-950/90 hover:bg-slate-900 border border-amber-800/80 hover:border-amber-500 text-left transition-all shadow-md cursor-pointer flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-amber-950 border border-amber-700/60 flex items-center justify-center shrink-0">
                <Hammer className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <div className="font-cinzel text-sm font-bold text-amber-200">
                  ARCANE FORGE
                </div>
                <div className="text-xs text-slate-400">
                  Upgrade & Evolve Staffs
                </div>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-amber-400 group-hover:translate-x-1 transition-transform" />
          </button>

          {/* Option 4: Weapon Loadouts */}
          <button
            onClick={() => {
              onSelectScreen('loadouts');
              sounds.playClick();
            }}
            className="group p-4 rounded-xl bg-slate-950/90 hover:bg-slate-900 border border-purple-800/80 hover:border-purple-500 text-left transition-all shadow-md cursor-pointer flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-purple-950 border border-purple-700/60 flex items-center justify-center shrink-0">
                <Layers className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <div className="font-cinzel text-sm font-bold text-purple-200">
                  STAFF LOADOUTS
                </div>
                <div className="text-xs text-slate-400">
                  Spell Slots & Builds
                </div>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-purple-400 group-hover:translate-x-1 transition-transform" />
          </button>

          {/* Option 5: Weapon Codex */}
          <button
            onClick={() => {
              onSelectScreen('collection');
              sounds.playClick();
            }}
            className="group p-4 rounded-xl bg-slate-950/90 hover:bg-slate-900 border border-emerald-800/80 hover:border-emerald-500 text-left transition-all shadow-md cursor-pointer flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-950 border border-emerald-700/60 flex items-center justify-center shrink-0">
                <BookOpen className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <div className="font-cinzel text-sm font-bold text-emerald-200">
                  WEAPON CODEX
                </div>
                <div className="text-xs text-slate-400">
                  Elemental Staff Catalog
                </div>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-emerald-400 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>

      {/* Bottom Footer Bar */}
      <div className="w-full max-w-5xl flex flex-col sm:flex-row items-center justify-between gap-3 pt-6 border-t border-slate-900 text-xs text-slate-500 z-10">
        <div>
          <span>Wizard Valley · Level 1 Apprentice Novice Save</span>
        </div>

        {/* Refill Mats helper for rapid testing of high level upgrades */}
        <div className="flex items-center gap-4">
          <button
            onClick={handleCheat}
            title="Refill gold and upgrade crystals for testing forge"
            className="text-xs text-slate-400 hover:text-amber-300 transition-colors flex items-center gap-1 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Refill Test Materials</span>
          </button>
          <span className="text-slate-700">·</span>
          <span>Auto-Saved to Browser Storage</span>
        </div>
      </div>

      {/* Refill Toast */}
      {cheatToast && (
        <div className="fixed bottom-6 right-6 bg-slate-900 border border-amber-500/50 text-amber-200 text-xs px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 animate-bounce z-50">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>Added +25,000 Gold, Ancient Cores, and Void Crystals for testing!</span>
        </div>
      )}
    </div>
  );
};
