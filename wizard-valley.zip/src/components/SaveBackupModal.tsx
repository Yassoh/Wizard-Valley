import React, { useState } from 'react';
import { 
  Save, 
  Download, 
  Upload, 
  RotateCcw, 
  Check, 
  Copy, 
  ShieldCheck, 
  AlertTriangle, 
  FileText 
} from 'lucide-react';
import { useGameSave } from '../context/GameSaveContext';
import { sounds } from '../utils/audio';

interface SaveBackupModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SaveBackupModal: React.FC<SaveBackupModalProps> = ({ isOpen, onClose }) => {
  const { saveData, exportSaveJson, importSaveJson, resetProgress } = useGameSave();
  const [importText, setImportText] = useState('');
  const [copied, setCopied] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  if (!isOpen) return null;

  const handleCopyJson = () => {
    const json = exportSaveJson();
    navigator.clipboard?.writeText(json);
    setCopied(true);
    sounds.playClick();
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const json = exportSaveJson();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `wizard-valley-save-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    sounds.playClick();
  };

  const handleImport = () => {
    if (!importText.trim()) return;
    const ok = importSaveJson(importText);
    if (ok) {
      setImportStatus('Save file successfully restored!');
      setTimeout(() => {
        setImportStatus(null);
        onClose();
      }, 1500);
    } else {
      setImportStatus('Error: Invalid JSON save file format.');
      setTimeout(() => setImportStatus(null), 3000);
    }
  };

  const handleReset = () => {
    resetProgress();
    setShowResetConfirm(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-6 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500/10 rounded-lg border border-amber-500/20 text-amber-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-100 font-cinzel">
                Wizard Valley Persistent Save System
              </h2>
              <div className="text-xs text-slate-400">
                Rule #75 Compliance: Continuous localStorage persistence across sessions.
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 text-xs px-2 py-1 cursor-pointer"
          >
            ✕ Close
          </button>
        </div>

        {/* Real-time Save Summary according to Section 75 categories */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 space-y-3">
          <div className="text-xs font-bold uppercase tracking-wider text-amber-400">
            Current Persistent State
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <span className="text-slate-500">Character:</span>
              <div className="font-semibold text-slate-200">{saveData.character.name}</div>
              <div className="text-[11px] text-slate-400">Lv. {saveData.character.level} · {saveData.character.robes}</div>
            </div>

            <div>
              <span className="text-slate-500">Progression:</span>
              <div className="font-semibold text-slate-200">{saveData.progression.completedMissions.length} Missions Done</div>
              <div className="text-[11px] text-slate-400">{saveData.progression.unlockedAreas.length} Areas Unlocked</div>
            </div>

            <div>
              <span className="text-slate-500">Economy:</span>
              <div className="font-semibold text-amber-400 font-mono">{saveData.economy.coins.toLocaleString()} Gold</div>
              <div className="text-[11px] text-slate-400">{saveData.economy.materials.magic_dust} Magic Dust</div>
            </div>

            <div>
              <span className="text-slate-500">Weapons:</span>
              <div className="font-semibold text-slate-200">{Object.keys(saveData.weapons.owned).length} Owned</div>
              <div className="text-[11px] text-slate-400">{saveData.weapons.loadouts.length} Saved Loadouts</div>
            </div>

            <div>
              <span className="text-slate-500">Multiplayer:</span>
              <div className="font-semibold text-slate-200">{saveData.multiplayerStats.wins} Wins / {saveData.multiplayerStats.matchesPlayed} Matches</div>
              <div className="text-[11px] text-slate-400">{saveData.multiplayerStats.bossesDefeated} Bosses Vanquished</div>
            </div>

            <div>
              <span className="text-slate-500">Collections:</span>
              <div className="font-semibold text-slate-200">{saveData.accessories.length} Accessories</div>
              <div className="text-[11px] text-slate-400">{saveData.collections.familiars.length} Familiars · {saveData.collections.titles.length} Titles</div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-900 flex items-center justify-between text-[11px] text-slate-500">
            <span>Auto-Save Status: Active in browser storage</span>
            <span className="font-mono">Last Synchronized: {new Date(saveData.lastSaved).toLocaleTimeString()}</span>
          </div>
        </div>

        {/* Export & Download Controls */}
        <div className="space-y-3">
          <div className="text-xs font-bold text-slate-200">
            Backup & Export Save File (JSON)
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={handleCopyJson}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied to Clipboard' : 'Copy Save JSON'}</span>
            </button>

            <button
              onClick={handleDownloadFile}
              className="px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download .JSON File</span>
            </button>
          </div>
        </div>

        {/* Import JSON Restore Area */}
        <div className="space-y-2">
          <div className="text-xs font-bold text-slate-200">
            Restore / Import Save File
          </div>
          <textarea
            value={importText}
            onChange={e => setImportText(e.target.value)}
            placeholder="Paste raw JSON save file content here to restore progress..."
            className="w-full h-24 bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs font-mono text-slate-300 focus:outline-none focus:border-amber-400"
          />
          {importStatus && (
            <div className="text-xs font-semibold text-amber-300">{importStatus}</div>
          )}
          <button
            onClick={handleImport}
            disabled={!importText.trim()}
            className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
              importText.trim()
                ? 'bg-slate-800 hover:bg-slate-700 text-white'
                : 'bg-slate-900 text-slate-600 cursor-not-allowed'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Apply Imported Save</span>
          </button>
        </div>

        {/* Reset Progress safeguard */}
        <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            Resetting returns profile to the rich default Lv. 32 archon state.
          </div>

          {showResetConfirm ? (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="text-xs text-slate-400 hover:text-slate-200 px-2 py-1"
              >
                Cancel
              </button>
              <button
                onClick={handleReset}
                className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer"
              >
                Confirm Reset
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowResetConfirm(true)}
              className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset to Defaults</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
