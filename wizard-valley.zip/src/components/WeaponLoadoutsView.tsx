import React, { useState } from 'react';
import { Layers, Zap, Flame, Shield, Check, Plus, Sparkles, Sword, ArrowLeft } from 'lucide-react';
import { useGameSave } from '../context/GameSaveContext';
import { WEAPONS_CATALOG } from '../data/weaponsData';
import { WeaponVisual } from './WeaponVisual';
import { sounds } from '../utils/audio';
import { ElementType } from '../types/game';

interface WeaponLoadoutsViewProps {
  onBackToMenu?: () => void;
}

export const WeaponLoadoutsView: React.FC<WeaponLoadoutsViewProps> = ({ onBackToMenu }) => {
  const { saveData, applyLoadout, saveNewLoadout } = useGameSave();
  const [activeLoadoutId, setActiveLoadoutId] = useState(saveData.weapons.activeLoadoutId || 'loadout_fire');
  const [isCreatingNew, setIsCreatingNew] = useState(false);

  // New loadout form state
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newStaffId, setNewStaffId] = useState('flame_staff');
  const [newElement, setNewElement] = useState<ElementType>('Fire');

  const currentLoadout = saveData.weapons.loadouts.find(l => l.id === activeLoadoutId) || saveData.weapons.loadouts[0];

  const handleApply = (id: string) => {
    setActiveLoadoutId(id);
    applyLoadout(id);
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    saveNewLoadout({
      name: newName,
      description: newDesc || 'Custom wizard battle build.',
      staffId: newStaffId,
      element: newElement,
      spells: ['Arcane Missile', 'Elemental Surge'],
      accessories: ['Archmage Crest', 'Dragon Eye Relic'],
    });
    setIsCreatingNew(false);
    setNewName('');
    setNewDesc('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/80 border border-slate-800 p-5 rounded-xl shadow-lg">
        <div>
          {onBackToMenu && (
            <button
              onClick={() => {
                sounds.playClick();
                onBackToMenu();
              }}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-amber-300 bg-slate-950/80 hover:bg-slate-900 border border-slate-800 px-3 py-1 rounded-lg transition-colors cursor-pointer mb-2"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>← Main Menu</span>
            </button>
          )}
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-wider">
            <Layers className="w-4 h-4 text-amber-400" />
            <span>Tactical Preset Grimoire</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-100 font-cinzel mt-1">
            Weapon & Spell Loadouts
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            Quickly adapt to elemental weaknesses by hot-swapping pre-configured staves, spells, and enchanted accessories.
          </p>
        </div>

        <button
          onClick={() => {
            setIsCreatingNew(true);
            sounds.playClick();
          }}
          className="px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow"
        >
          <Plus className="w-4 h-4" />
          <span>New Custom Loadout</span>
        </button>
      </div>

      {/* Loadouts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {saveData.weapons.loadouts.map(loadout => {
          const isActive = saveData.weapons.equippedId === loadout.staffId;
          const staffMeta = WEAPONS_CATALOG.find(w => w.id === loadout.staffId);
          const owned = staffMeta ? saveData.weapons.owned[staffMeta.id] : undefined;

          return (
            <div
              key={loadout.id}
              className={`rounded-xl border p-5 transition-all flex flex-col justify-between ${
                isActive
                  ? 'bg-slate-900 border-amber-400 shadow-xl ring-2 ring-amber-400/20'
                  : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    {loadout.element} Focus
                  </span>
                  {isActive && (
                    <span className="text-[10px] font-bold uppercase bg-amber-400 text-slate-950 px-2 py-0.5 rounded">
                      Active
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  {staffMeta && (
                    <WeaponVisual
                      element={staffMeta.element}
                      name={staffMeta.name}
                      isEvolved={owned?.isEvolved}
                      skinId={owned?.selectedSkin}
                      size="md"
                    />
                  )}
                  <div>
                    <h3 className="font-bold text-base text-slate-100 font-cinzel">
                      {loadout.name}
                    </h3>
                    <div className="text-xs text-slate-400 mt-0.5">
                      Staff: <strong className="text-slate-200">{staffMeta?.name || loadout.staffId}</strong>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed">
                  {loadout.description}
                </p>

                {/* Spells list */}
                <div className="space-y-1 pt-2 border-t border-slate-800">
                  <span className="text-[11px] font-medium text-slate-400">Attuned Spells:</span>
                  <div className="flex flex-wrap gap-1 text-[11px]">
                    {loadout.spells.map((spell, i) => (
                      <span key={i} className="bg-slate-900 border border-slate-800 px-2 py-0.5 rounded text-slate-300">
                        {spell}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Accessories list */}
                <div className="space-y-1">
                  <span className="text-[11px] font-medium text-slate-400">Enchanted Accessories:</span>
                  <div className="flex flex-wrap gap-1 text-[11px]">
                    {loadout.accessories.map((acc, i) => (
                      <span key={i} className="bg-slate-900/80 border border-slate-800 px-2 py-0.5 rounded text-amber-200/80">
                        {acc}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-800">
                <button
                  onClick={() => handleApply(loadout.id)}
                  disabled={isActive}
                  className={`w-full py-2 text-xs font-bold rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
                    isActive
                      ? 'bg-slate-800 text-slate-500 cursor-default'
                      : 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow'
                  }`}
                >
                  {isActive ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Current Build</span>
                    </>
                  ) : (
                    <>
                      <Sword className="w-3.5 h-3.5" />
                      <span>Equip Build</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal / Form: Create New Loadout */}
      {isCreatingNew && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-slate-100 font-cinzel">
                Create Weapon Loadout
              </h3>
              <button
                onClick={() => setIsCreatingNew(false)}
                className="text-slate-400 hover:text-slate-200 text-xs cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Build Name
                </label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  placeholder="e.g. DUAL VOLTEX HYPER-BURST"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Tactical Purpose
                </label>
                <input
                  type="text"
                  value={newDesc}
                  onChange={e => setNewDesc(e.target.value)}
                  placeholder="e.g. Specialized for high mobility and void boss interruption."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    Magic Staff
                  </label>
                  <select
                    value={newStaffId}
                    onChange={e => {
                      setNewStaffId(e.target.value);
                      const w = WEAPONS_CATALOG.find(x => x.id === e.target.value);
                      if (w) setNewElement(w.element);
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none"
                  >
                    {WEAPONS_CATALOG.map(w => (
                      <option key={w.id} value={w.id}>
                        {w.name} ({w.element})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    Primary Element
                  </label>
                  <input
                    type="text"
                    readOnly
                    value={newElement}
                    className="w-full bg-slate-950/50 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-400"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsCreatingNew(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-lg transition-colors cursor-pointer"
                >
                  Save Loadout
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
