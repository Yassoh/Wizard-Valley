import React, { useState } from 'react';
import { 
  Hammer, 
  Sparkles, 
  Flame, 
  Shield, 
  Zap, 
  Layers, 
  Check, 
  Eye, 
  ArrowUpRight, 
  Info, 
  Compass, 
  Coins, 
  Package, 
  ChevronRight,
  AlertCircle,
  ArrowLeft
} from 'lucide-react';
import { WEAPONS_CATALOG, getUpgradeCost, getEvolutionCost } from '../data/weaponsData';
import { MATERIALS } from '../data/materialsData';
import { WeaponItem, WeaponOwnedState } from '../types/game';
import { useGameSave } from '../context/GameSaveContext';
import { WeaponVisual } from './WeaponVisual';
import { sounds } from '../utils/audio';

interface ArcaneForgeViewProps {
  onBackToMenu?: () => void;
}

export const ArcaneForgeView: React.FC<ArcaneForgeViewProps> = ({ onBackToMenu }) => {
  const { 
    saveData, 
    upgradeWeapon, 
    evolveWeapon, 
    equipWeapon, 
    changeSkin 
  } = useGameSave();

  const [selectedWeaponId, setSelectedWeaponId] = useState<string>(
    saveData.weapons.equippedId || 'flame_staff'
  );
  const [activeTab, setActiveTab] = useState<'upgrade' | 'evolution' | 'cosmetics' | 'materials'>('upgrade');
  const [statusMessage, setStatusMessage] = useState<{ text: string; isError: boolean } | null>(null);
  const [forgingAnimation, setForgingAnimation] = useState(false);

  const selectedWeapon = WEAPONS_CATALOG.find(w => w.id === selectedWeaponId) || WEAPONS_CATALOG[1];
  const ownedState: WeaponOwnedState | undefined = saveData.weapons.owned[selectedWeapon.id];
  const isEquipped = saveData.weapons.equippedId === selectedWeapon.id;
  const isOwned = !!ownedState;
  const isMaxLevel = (ownedState?.upgradeLevel || 0) >= 10;
  const isEvolved = !!ownedState?.isEvolved;

  const currentLevel = ownedState?.upgradeLevel || 0;
  const upgradeCost = isOwned && !isMaxLevel ? getUpgradeCost(currentLevel, selectedWeapon.element) : null;
  const evolutionCost = isOwned && isMaxLevel && !isEvolved ? getEvolutionCost(selectedWeapon) : null;

  // Calculate current upgraded stats
  const damageBonusPercent = currentLevel * 5; // e.g. Lv 10 = +50%
  const currentDamage = Math.round(selectedWeapon.baseDamage * (1 + damageBonusPercent / 100) + (isEvolved ? (selectedWeapon.evolvedDamageBonus || 80) : 0));
  const nextDamage = Math.round(selectedWeapon.baseDamage * (1 + (damageBonusPercent + 5) / 100));
  const currentElementalPower = selectedWeapon.elementalPower + currentLevel * 2 + (isEvolved ? 25 : 0);

  const handleUpgrade = () => {
    setForgingAnimation(true);
    const result = upgradeWeapon(selectedWeapon.id);
    setTimeout(() => {
      setForgingAnimation(false);
      setStatusMessage({ text: result.message, isError: !result.success });
    }, 300);
    setTimeout(() => setStatusMessage(null), 4000);
  };

  const handleEvolve = () => {
    setForgingAnimation(true);
    const result = evolveWeapon(selectedWeapon.id);
    setTimeout(() => {
      setForgingAnimation(false);
      setStatusMessage({ text: result.message, isError: !result.success });
    }, 500);
    setTimeout(() => setStatusMessage(null), 5000);
  };

  return (
    <div className="space-y-6">
      {/* Arcane Forge Atmospheric Banner */}
      <div className="relative rounded-2xl overflow-hidden border border-slate-800 shadow-2xl bg-slate-950">
        <div className="relative h-48 sm:h-56 w-full">
          <img
            src="/src/assets/images/arcane_forge_interior_1790256970252.jpg"
            alt="Arcane Forge Interior"
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />
          
          <div className="absolute inset-0 p-6 flex flex-col justify-end">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div>
                {onBackToMenu && (
                  <button
                    onClick={() => {
                      sounds.playClick();
                      onBackToMenu();
                    }}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-300 hover:text-amber-300 bg-slate-950/80 hover:bg-slate-900 border border-slate-700/80 px-3 py-1 rounded-lg transition-colors cursor-pointer mb-2 backdrop-blur-sm"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>← Main Menu</span>
                  </button>
                )}
                <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-widest">
                  <Hammer className="w-4 h-4 text-amber-400" />
                  <span>The Grand Arcane Forge</span>
                  <span className="text-slate-500">·</span>
                  <span className="text-slate-300">Level {saveData.character.level} Mage Blacksmith</span>
                </div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-cinzel tracking-wide mt-1">
                  Elemental Anvil & Staff Transmutation
                </h1>
                <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mt-1 leading-relaxed">
                  Infuse magical staffs with primordial minerals, unlock specialized elemental abilities, and trigger mythic weapon evolution.
                </p>
              </div>

              {/* Quick Forge Currency Display */}
              <div className="flex items-center gap-4 bg-slate-950/90 border border-slate-800/80 px-4 py-2.5 rounded-xl text-xs backdrop-blur-sm">
                <div>
                  <div className="text-slate-400">Citadel Gold</div>
                  <div className="font-bold text-amber-400 text-sm tabular-nums">
                    {saveData.economy.coins.toLocaleString()}
                  </div>
                </div>
                <div className="h-6 w-px bg-slate-800" />
                <div>
                  <div className="text-slate-400">Magic Dust</div>
                  <div className="font-bold text-cyan-300 text-sm tabular-nums">
                    {saveData.economy.materials.magic_dust}
                  </div>
                </div>
                <div className="h-6 w-px bg-slate-800" />
                <div>
                  <div className="text-slate-400">Ancient Cores</div>
                  <div className="font-bold text-purple-300 text-sm tabular-nums">
                    {saveData.economy.materials.ancient_core}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Status Toast */}
        {statusMessage && (
          <div
            className={`p-3 text-xs font-semibold flex items-center gap-2 border-t ${
              statusMessage.isError
                ? 'bg-red-950/80 border-red-800 text-red-200'
                : 'bg-emerald-950/80 border-emerald-800 text-emerald-200'
            }`}
          >
            {statusMessage.isError ? <AlertCircle className="w-4 h-4 text-red-400" /> : <Check className="w-4 h-4 text-emerald-400" />}
            <span>{statusMessage.text}</span>
          </div>
        )}
      </div>

      {/* Main Forge Workbench: Weapons Carousel & Interactive Station */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Weapons Selector (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-300 font-cinzel">
              Staff Arsenal
            </h2>
            <span className="text-xs text-slate-500 tabular-nums">
              {Object.keys(saveData.weapons.owned).length} Owned
            </span>
          </div>

          <div className="space-y-2 max-h-[640px] overflow-y-auto pr-1">
            {WEAPONS_CATALOG.map(weapon => {
              const owned = saveData.weapons.owned[weapon.id];
              const isSelected = weapon.id === selectedWeapon.id;
              const meetsLevelReq = saveData.character.level >= weapon.levelReq;
              const equipped = saveData.weapons.equippedId === weapon.id;

              return (
                <div
                  key={weapon.id}
                  onClick={() => {
                    setSelectedWeaponId(weapon.id);
                    sounds.playClick();
                  }}
                  className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    isSelected
                      ? 'bg-slate-900 border-amber-400/80 shadow-md ring-1 ring-amber-400/30'
                      : 'bg-slate-950/70 border-slate-800/90 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <WeaponVisual
                        element={weapon.element}
                        name={weapon.name}
                        isEvolved={owned?.isEvolved}
                        skinId={owned?.selectedSkin}
                        size="md"
                      />
                      {equipped && (
                        <div className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-slate-950" />
                      )}
                    </div>

                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-sm text-slate-100 font-cinzel">
                          {owned?.isEvolved ? (weapon.evolvedName || weapon.name) : weapon.name}
                        </span>
                      </div>

                      <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                        <span style={{ color: weapon.themeColor }}>{weapon.element}</span>
                        <span className="text-slate-600">·</span>
                        {owned ? (
                          <span className="text-amber-400 font-medium">
                            {owned.isEvolved ? 'Mythic Evolved' : `Upgrade ${owned.upgradeLevel}/10`}
                          </span>
                        ) : (
                          <span className="text-slate-500">
                            Req. Lv. {weapon.levelReq}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    {equipped ? (
                      <span className="text-[10px] font-bold uppercase text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
                        Equipped
                      </span>
                    ) : owned ? (
                      <ChevronRight className="w-4 h-4 text-slate-600" />
                    ) : (
                      <span className="text-[10px] font-medium text-slate-500">
                        {meetsLevelReq ? 'Unlocked' : `Lv. ${weapon.levelReq}`}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Active Staff Inspection & Upgrade Console (8 cols) */}
        <div className="lg:col-span-8 space-y-5">
          {/* Main Inspection Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
            {/* Forge Sparks Background when forging */}
            {forgingAnimation && (
              <div className="absolute inset-0 bg-amber-500/20 z-20 backdrop-blur-xs flex items-center justify-center animate-pulse">
                <div className="text-center space-y-2">
                  <Hammer className="w-12 h-12 text-amber-300 mx-auto animate-bounce" />
                  <div className="text-sm font-bold text-amber-200 font-cinzel">
                    Channeling Arcane Runes...
                  </div>
                </div>
              </div>
            )}

            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-5 border-b border-slate-800">
              <div className="flex items-center gap-4">
                <WeaponVisual
                  element={selectedWeapon.element}
                  name={selectedWeapon.name}
                  isEvolved={isEvolved}
                  skinId={ownedState?.selectedSkin}
                  size="xl"
                />

                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded"
                      style={{ backgroundColor: `${selectedWeapon.themeColor}25`, color: selectedWeapon.themeColor }}
                    >
                      {selectedWeapon.element} School
                    </span>
                    {isEvolved && (
                      <span className="text-xs font-black tracking-wider text-amber-300 bg-amber-950/70 border border-amber-600/60 px-2 py-0.5 rounded flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-amber-400" />
                        MYTHIC EVOLUTION
                      </span>
                    )}
                  </div>

                  <h2 className="text-2xl font-bold text-slate-100 font-cinzel">
                    {isEvolved ? selectedWeapon.evolvedName : selectedWeapon.name}
                  </h2>

                  <div className="text-xs text-slate-400 flex items-center gap-3">
                    <span>
                      Upgrade Level: <strong className="text-amber-400">{currentLevel}/10</strong>
                    </span>
                    <span className="text-slate-600">·</span>
                    <span>
                      Required Mage Level: <strong className="text-slate-200">{selectedWeapon.levelReq}</strong>
                    </span>
                  </div>
                </div>
              </div>

              {/* Equip Action */}
              {isOwned && !isEquipped && (
                <button
                  onClick={() => equipWeapon(selectedWeapon.id)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-semibold rounded-lg transition-colors cursor-pointer border border-slate-700 flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Equip as Active Staff</span>
                </button>
              )}
            </div>

            {/* Section 65: Weapon Stats Display */}
            <div className="py-5 grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
                <span className="text-[11px] text-slate-400">Total Damage</span>
                <div className="text-lg font-bold text-slate-100 tabular-nums font-mono mt-0.5">
                  {currentDamage}
                </div>
                <div className="text-[10px] text-amber-400">
                  +{damageBonusPercent}% upgrade bonus
                </div>
              </div>

              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
                <span className="text-[11px] text-slate-400">Elemental Power</span>
                <div className="text-lg font-bold text-slate-100 tabular-nums font-mono mt-0.5">
                  {currentElementalPower}%
                </div>
                <div className="text-[10px] text-cyan-400">
                  {selectedWeapon.element} scaling
                </div>
              </div>

              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
                <span className="text-[11px] text-slate-400">Cast Velocity</span>
                <div className="text-lg font-bold text-slate-100 tabular-nums font-mono mt-0.5">
                  {selectedWeapon.attackSpeed} / sec
                </div>
                <div className="text-[10px] text-slate-400">
                  Proj Speed: {selectedWeapon.projectileSpeed}
                </div>
              </div>

              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
                <span className="text-[11px] text-slate-400">Critical Chance</span>
                <div className="text-lg font-bold text-slate-100 tabular-nums font-mono mt-0.5">
                  {selectedWeapon.critChance}%
                </div>
                <div className="text-[10px] text-emerald-400">
                  Efficiency: {selectedWeapon.manaEfficiency}%
                </div>
              </div>
            </div>

            {/* Section 66: Special Ability Panel */}
            <div className="p-4 bg-slate-950/90 border border-slate-800 rounded-xl space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Special Weapon Ability</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-medium">
                {isEvolved && selectedWeapon.evolvedSpecialEffect
                  ? selectedWeapon.evolvedSpecialEffect
                  : selectedWeapon.specialEffect}
              </p>
            </div>

            {/* Sub Tabs: Upgrade vs Evolution vs Cosmetics vs Materials */}
            <div className="flex items-center gap-2 mt-5 pt-4 border-t border-slate-800">
              <button
                onClick={() => {
                  setActiveTab('upgrade');
                  sounds.playClick();
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'upgrade'
                    ? 'bg-amber-400 text-slate-950'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                <Hammer className="w-3.5 h-3.5" />
                <span>Weapon Upgrading ({currentLevel}/10)</span>
              </button>

              <button
                onClick={() => {
                  setActiveTab('evolution');
                  sounds.playClick();
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'evolution'
                    ? 'bg-purple-500 text-white'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Weapon Evolution</span>
              </button>

              <button
                onClick={() => {
                  setActiveTab('cosmetics');
                  sounds.playClick();
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'cosmetics'
                    ? 'bg-cyan-500 text-slate-950'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Cosmetic Skins</span>
              </button>

              <button
                onClick={() => {
                  setActiveTab('materials');
                  sounds.playClick();
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer flex items-center gap-1.5 ${
                  activeTab === 'materials'
                    ? 'bg-slate-700 text-white'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                <Package className="w-3.5 h-3.5" />
                <span>Material Pouch</span>
              </button>
            </div>

            {/* TAB CONTENT: Section 64 Weapon Upgrade */}
            {activeTab === 'upgrade' && (
              <div className="mt-4 space-y-4">
                {isMaxLevel ? (
                  <div className="p-4 bg-purple-950/30 border border-purple-800/50 rounded-xl flex items-center justify-between gap-4">
                    <div>
                      <div className="text-sm font-bold text-purple-300 font-cinzel">
                        Maximum Upgrade Level 10 Achieved!
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">
                        This staff has absorbed all conventional elemental infusions. Switch to the <strong>Weapon Evolution</strong> tab to unleash its Mythic form.
                      </p>
                    </div>
                    <button
                      onClick={() => setActiveTab('evolution')}
                      className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                    >
                      View Evolution
                    </button>
                  </div>
                ) : upgradeCost ? (
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="text-xs font-bold text-slate-200">
                        Upgrade to Level {currentLevel + 1}/10:
                      </div>
                      <div className="text-xs text-emerald-400 font-mono font-bold">
                        Damage: {currentDamage} → {nextDamage} (+5%)
                      </div>
                    </div>

                    {/* Materials Needed */}
                    <div className="flex flex-wrap items-center gap-3 text-xs">
                      <div className="flex items-center gap-1.5 bg-slate-900 px-3 py-1.5 rounded-md border border-slate-800">
                        <Coins className="w-3.5 h-3.5 text-amber-400" />
                        <span className="text-slate-400">Coins:</span>
                        <span className={`font-mono font-bold ${saveData.economy.coins >= upgradeCost.coins ? 'text-amber-300' : 'text-red-400'}`}>
                          {upgradeCost.coins.toLocaleString()}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 bg-slate-900 px-3 py-1.5 rounded-md border border-slate-800">
                        <span className="w-2 h-2 rounded-full bg-cyan-400" />
                        <span className="text-slate-400">Magic Dust:</span>
                        <span className={`font-mono font-bold ${saveData.economy.materials.magic_dust >= upgradeCost.magicDust ? 'text-cyan-300' : 'text-red-400'}`}>
                          {saveData.economy.materials.magic_dust} / {upgradeCost.magicDust}
                        </span>
                      </div>

                      {upgradeCost.crystals.map(c => {
                        const meta = MATERIALS[c.key];
                        const count = saveData.economy.materials[c.key] || 0;
                        const hasEnough = count >= c.amount;
                        return (
                          <div key={c.key} className="flex items-center gap-1.5 bg-slate-900 px-3 py-1.5 rounded-md border border-slate-800">
                            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: meta?.color || '#cbd5e1' }} />
                            <span className="text-slate-400">{meta?.name || c.key}:</span>
                            <span className={`font-mono font-bold ${hasEnough ? 'text-slate-200' : 'text-red-400'}`}>
                              {count} / {c.amount}
                            </span>
                          </div>
                        );
                      })}
                    </div>

                    <button
                      onClick={handleUpgrade}
                      className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-md font-cinzel"
                    >
                      <Hammer className="w-4 h-4 text-slate-950" />
                      <span>FORGE UPGRADE (LEVEL {currentLevel + 1})</span>
                    </button>
                  </div>
                ) : null}
              </div>
            )}

            {/* TAB CONTENT: Section 67 Weapon Evolution */}
            {activeTab === 'evolution' && (
              <div className="mt-4 space-y-4">
                {isEvolved ? (
                  <div className="p-4 bg-emerald-950/30 border border-emerald-800/50 rounded-xl text-center space-y-1">
                    <Sparkles className="w-6 h-6 text-emerald-400 mx-auto" />
                    <div className="text-sm font-bold text-emerald-300 font-cinzel">
                      {selectedWeapon.evolvedName} Active!
                    </div>
                    <p className="text-xs text-slate-400">
                      This weapon has transcended mortals and reached apex cosmic attunement.
                    </p>
                  </div>
                ) : (
                  <div className="bg-slate-950 p-5 rounded-xl border border-purple-900/50 space-y-4">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                      <div>
                        <div className="text-xs uppercase tracking-widest text-purple-400 font-bold flex items-center gap-1">
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Apex Transmutation Target</span>
                        </div>
                        <h3 className="text-xl font-bold text-white font-cinzel">
                          {selectedWeapon.evolvedName || 'Ascended Staff'}
                        </h3>
                      </div>
                      <span className="text-xs font-bold text-amber-400 bg-amber-950/60 border border-amber-800/60 px-2 py-1 rounded">
                        +{selectedWeapon.evolvedDamageBonus || 95} Base Power
                      </span>
                    </div>

                    <div className="p-3 bg-purple-950/20 border border-purple-800/30 rounded-lg text-xs text-purple-200">
                      <strong>New Mythic Ability: </strong>
                      {selectedWeapon.evolvedSpecialEffect}
                    </div>

                    {/* Evolution Requirements */}
                    {evolutionCost && (
                      <div className="space-y-2">
                        <div className="text-xs font-semibold text-slate-400">
                          Evolution Catalysts Required:
                        </div>
                        <div className="flex flex-wrap gap-2 text-xs">
                          <div className="bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
                            Coins: <strong className="text-amber-400">{evolutionCost.coins.toLocaleString()}</strong>
                          </div>
                          {evolutionCost.crystals.map(c => {
                            const meta = MATERIALS[c.key];
                            const current = saveData.economy.materials[c.key] || 0;
                            const ok = current >= c.amount;
                            return (
                              <div key={c.key} className="bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
                                {meta?.name}: <strong className={ok ? 'text-emerald-400' : 'text-red-400'}>{current}/{c.amount}</strong>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    <button
                      onClick={handleEvolve}
                      disabled={!isMaxLevel}
                      className={`w-full py-3.5 font-bold text-sm rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer font-cinzel ${
                        isMaxLevel
                          ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-lg'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>
                        {isMaxLevel ? 'TRIGGER ARCANE EVOLUTION' : 'REACH LEVEL 10 UPGRADE FIRST'}
                      </span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* TAB CONTENT: Cosmetics */}
            {activeTab === 'cosmetics' && (
              <div className="mt-4 space-y-3">
                <div className="text-xs text-slate-400">
                  Switch the cosmetic finish and visual aura of your staff. Cosmetics do not affect competitive normalized stats.
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {selectedWeapon.availableSkins.map(skin => {
                    const activeSkin = ownedState?.selectedSkin === skin.id;
                    return (
                      <div
                        key={skin.id}
                        onClick={() => changeSkin(selectedWeapon.id, skin.id)}
                        className={`p-3 rounded-xl border transition-all cursor-pointer ${
                          activeSkin
                            ? 'bg-amber-950/30 border-amber-400 text-amber-200'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between font-semibold text-xs text-slate-200">
                          <span>{skin.name}</span>
                          {activeSkin && <Check className="w-3.5 h-3.5 text-amber-400" />}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-1 leading-snug">
                          {skin.visualDesc}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB CONTENT: Section 68 Materials Pouch */}
            {activeTab === 'materials' && (
              <div className="mt-4 space-y-3">
                <div className="text-xs text-slate-400">
                  Upgrade & Evolution reagents in your Citadel Bag. Hover/click for drop sources.
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {Object.values(MATERIALS).map(mat => {
                    const count = saveData.economy.materials[mat.key] || 0;
                    return (
                      <div
                        key={mat.key}
                        className="p-2.5 bg-slate-950 border border-slate-800 rounded-lg space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: mat.color }} />
                            <span className="text-xs font-semibold text-slate-200 truncate max-w-[110px]">
                              {mat.name}
                            </span>
                          </div>
                          <span className="text-xs font-mono font-bold text-amber-400 tabular-nums">
                            {count}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-500 line-clamp-1">
                          From: {mat.sources.join(', ')}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
