import React, { useState } from 'react';
import { 
  Users, 
  MapPin, 
  Flame, 
  ShieldAlert, 
  Lock, 
  Unlock, 
  Clock, 
  Skull, 
  Zap, 
  AlertTriangle, 
  Copy, 
  Check, 
  Crown, 
  UserX, 
  Plus, 
  ArrowRight,
  ArrowLeft,
  Sliders,
  Sparkles,
  Scale,
  Settings2,
  RefreshCw
} from 'lucide-react';
import { 
  RoomSettings, 
  RoomPlayer, 
  PresetType, 
  DifficultyLevel, 
  GameModeType, 
  BossFrequencyType, 
  BalancingMode 
} from '../types/game';
import { MAPS_LIST } from '../data/mapsData';
import { sounds } from '../utils/audio';
import { useGameSave } from '../context/GameSaveContext';

interface RoomSettingsViewProps {
  onStartMatch: (settings: RoomSettings, players: RoomPlayer[]) => void;
  onBackToMenu?: () => void;
}

const DEFAULT_SETTINGS: RoomSettings = {
  roomName: 'Wizard Valley Leyline Sanctum',
  roomType: 'PUBLIC',
  roomCode: 'ARC-789',
  isLocked: false,
  gameMode: 'Co-Op Survival',
  mapId: 'crystal_caves',
  difficulty: 'Hard',
  preset: 'CUSTOM',
  maxPlayers: 4,
  friendlyFire: false,
  teamMode: true,
  timeLimitMinutes: 15,
  enemyWaves: 15,
  bossFrequency: 'HIGH',
  playerRespawns: true,
  weaponBalancing: 'PROGRESSION',
  chaosModifiers: {
    fasterEnemies: false,
    randomElements: false,
    moreBosses: false,
    reducedHealing: false,
    lowGravity: false,
    increasedSpellSpeed: false,
    randomEnvironmentalEvents: false,
  },
};

export const RoomSettingsView: React.FC<RoomSettingsViewProps> = ({ onStartMatch, onBackToMenu }) => {
  const { saveData, equippedWeaponData } = useGameSave();
  const [settings, setSettings] = useState<RoomSettings>(DEFAULT_SETTINGS);
  const [copiedCode, setCopiedCode] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'settings' | 'map_picker' | 'lobby' | 'summary'>('settings');

  // Room players simulation
  const [players, setPlayers] = useState<RoomPlayer[]>([
    {
      id: 'host_player',
      name: saveData.character.name,
      level: saveData.character.level,
      staffId: saveData.weapons.equippedId,
      staffName: equippedWeaponData?.name || 'Apprentice Staff',
      staffLevel: saveData.weapons.owned[saveData.weapons.equippedId]?.upgradeLevel ?? 0,
      isEvolved: saveData.weapons.owned[saveData.weapons.equippedId]?.isEvolved || false,
      isHost: true,
      isReady: true,
      ping: 18,
      roleTitle: saveData.character.title,
      avatarSeed: 'player',
      avatarColor: '#f59e0b',
    },
    {
      id: 'player_lyra',
      name: 'Novice Lyra',
      level: 1,
      staffId: 'frost_staff',
      staffName: 'Frost Staff',
      staffLevel: 0,
      isEvolved: false,
      isHost: false,
      isReady: true,
      ping: 34,
      roleTitle: 'Ice Initiate',
      avatarSeed: 'lyra',
      avatarColor: '#38bdf8',
    },
    {
      id: 'player_torin',
      name: 'Apprentice Torin',
      level: 2,
      staffId: 'storm_staff',
      staffName: 'Storm Staff',
      staffLevel: 1,
      isEvolved: false,
      isHost: false,
      isReady: true,
      ping: 42,
      roleTitle: 'Spark Adept',
      avatarSeed: 'torin',
      avatarColor: '#eab308',
    },
  ]);

  const selectedMap = MAPS_LIST.find(m => m.id === settings.mapId) || MAPS_LIST[0];

  const applyPreset = (preset: PresetType) => {
    sounds.playClick();
    if (preset === 'CASUAL') {
      setSettings(prev => ({
        ...prev,
        preset: 'CASUAL',
        difficulty: 'Casual',
        timeLimitMinutes: 20,
        playerRespawns: true,
        friendlyFire: false,
        bossFrequency: 'LOW',
        enemyWaves: 10,
        chaosModifiers: {
          fasterEnemies: false,
          randomElements: false,
          moreBosses: false,
          reducedHealing: false,
          lowGravity: false,
          increasedSpellSpeed: false,
          randomEnvironmentalEvents: false,
        },
      }));
    } else if (preset === 'CHALLENGE') {
      setSettings(prev => ({
        ...prev,
        preset: 'CHALLENGE',
        difficulty: 'Hard',
        timeLimitMinutes: 15,
        playerRespawns: true,
        friendlyFire: false,
        bossFrequency: 'HIGH',
        enemyWaves: 15,
        chaosModifiers: {
          fasterEnemies: true,
          randomElements: false,
          moreBosses: true,
          reducedHealing: false,
          lowGravity: false,
          increasedSpellSpeed: false,
          randomEnvironmentalEvents: false,
        },
      }));
    } else if (preset === 'CHAOS') {
      setSettings(prev => ({
        ...prev,
        preset: 'CHAOS',
        difficulty: 'Nightmare',
        timeLimitMinutes: 10,
        playerRespawns: true,
        friendlyFire: true,
        bossFrequency: 'EXTREME',
        enemyWaves: 20,
        chaosModifiers: {
          fasterEnemies: true,
          randomElements: true,
          moreBosses: true,
          reducedHealing: true,
          lowGravity: true,
          increasedSpellSpeed: true,
          randomEnvironmentalEvents: true,
        },
      }));
    } else {
      setSettings(prev => ({ ...prev, preset: 'CUSTOM' }));
    }
  };

  const copyRoomCode = () => {
    navigator.clipboard?.writeText(settings.roomCode);
    setCopiedCode(true);
    sounds.playClick();
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const toggleLock = () => {
    setSettings(prev => ({ ...prev, isLocked: !prev.isLocked }));
    sounds.playClick();
  };

  const kickPlayer = (playerId: string) => {
    if (playerId === 'host_player') return;
    setPlayers(prev => prev.filter(p => p.id !== playerId));
    sounds.playClick();
  };

  const transferHost = (newHostId: string) => {
    setPlayers(prev =>
      prev.map(p => ({
        ...p,
        isHost: p.id === newHostId,
      }))
    );
    sounds.playUpgrade();
  };

  const addBotPlayer = () => {
    if (players.length >= settings.maxPlayers) return;
    const botNames = ['Apprentice Kael', 'Seer Vanya', 'Pyromancer Jax', 'Cryo Sage Eldon', 'Void Disciple Nyx'];
    const available = botNames.find(n => !players.some(p => p.name === n)) || `Conjured Mage ${players.length + 1}`;
    const newBot: RoomPlayer = {
      id: `bot_${Date.now()}`,
      name: available,
      level: Math.floor(20 + Math.random() * 15),
      staffId: 'earth_staff',
      staffName: 'Titan Staff',
      staffLevel: 7,
      isEvolved: false,
      isHost: false,
      isReady: true,
      ping: Math.floor(25 + Math.random() * 30),
      roleTitle: 'Earthen Mystic',
      avatarSeed: `bot_${players.length}`,
      avatarColor: '#10b981',
    };
    setPlayers(prev => [...prev, newBot]);
    sounds.playClick();
  };

  // Check unfair conditions according to Section 58 & 71
  const unfairConditions: string[] = [];
  if (settings.friendlyFire) {
    unfairConditions.push('Friendly Fire is ON: Spells will damage and interrupt teammates.');
  }
  if (!settings.playerRespawns) {
    unfairConditions.push('Respawns OFF: Fallen mages cannot be revived during wave gauntlets.');
  }
  if (settings.gameMode === 'PvP Arena' && settings.weaponBalancing === 'PROGRESSION') {
    unfairConditions.push('Progression Gear in PvP: Players with max-upgraded weapons have stat advantages over recruits.');
  }
  if (settings.chaosModifiers.reducedHealing) {
    unfairConditions.push('Chaos Modifier: Healing spells and potions effectiveness reduced by 60%.');
  }
  if (settings.chaosModifiers.moreBosses && settings.difficulty === 'Mythic') {
    unfairConditions.push('Cataclysmic Threat: Multiple mythic tier bosses spawn simultaneously.');
  }

  const handleStartGame = () => {
    sounds.playUpgrade();
    onStartMatch(settings, players);
  };

  return (
    <div className="space-y-6">
      {/* Host Room Header */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 shadow-xl relative overflow-hidden">
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 relative z-10">
          <div className="space-y-1">
            {onBackToMenu && (
              <button
                onClick={() => {
                  sounds.playClick();
                  onBackToMenu();
                }}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-amber-300 bg-slate-950/80 hover:bg-slate-900 border border-slate-800 px-3 py-1 rounded-lg transition-colors cursor-pointer mb-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>← Main Menu</span>
              </button>
            )}
            <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold tracking-wider uppercase">
              <Crown className="w-4 h-4 text-amber-400" />
              <span>Host Console</span>
              <span className="text-slate-600">·</span>
              <span className="text-slate-400">{settings.roomType} LOBBY</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold font-cinzel text-slate-100">
              {settings.roomName}
            </h1>
            <p className="text-sm text-slate-400">
              Configure room parameters, environmental hazards, player limits, and game modifiers.
            </p>
          </div>

          {/* Room Code & Privacy Affordances */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-950/80 border border-slate-800 px-3 py-2 rounded-lg">
              <span className="text-xs text-slate-400">Room Code:</span>
              <span className="font-mono text-sm font-bold text-amber-300 tracking-widest">
                {settings.roomCode}
              </span>
              <button
                onClick={copyRoomCode}
                title="Copy Room Code"
                className="text-slate-400 hover:text-amber-400 transition-colors p-1 cursor-pointer"
              >
                {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            <button
              onClick={toggleLock}
              className={`px-3 py-2 text-xs font-semibold rounded-lg border transition-colors flex items-center gap-1.5 cursor-pointer ${
                settings.isLocked
                  ? 'bg-red-950/40 border-red-700/60 text-red-300 hover:bg-red-900/40'
                  : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:border-slate-700'
              }`}
            >
              {settings.isLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
              <span>{settings.isLocked ? 'Room Locked' : 'Room Open'}</span>
            </button>

            {/* Quick Summary / Launch direct trigger */}
            <button
              onClick={() => setActiveSubTab('summary')}
              className="px-4 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shadow-md"
            >
              <span>Review & Start Game</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Sub Navigation */}
        <div className="flex items-center gap-1 mt-6 pt-4 border-t border-slate-800/80 overflow-x-auto text-xs">
          <button
            onClick={() => {
              setActiveSubTab('settings');
              sounds.playClick();
            }}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              activeSubTab === 'settings'
                ? 'bg-amber-400/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Basic & Advanced Settings
          </button>
          <button
            onClick={() => {
              setActiveSubTab('map_picker');
              sounds.playClick();
            }}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'map_picker'
                ? 'bg-amber-400/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>Map Selection ({selectedMap.name})</span>
          </button>
          <button
            onClick={() => {
              setActiveSubTab('lobby');
              sounds.playClick();
            }}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'lobby'
                ? 'bg-amber-400/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Party Management ({players.length}/{settings.maxPlayers})</span>
          </button>
          <button
            onClick={() => {
              setActiveSubTab('summary');
              sounds.playClick();
            }}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'summary'
                ? 'bg-amber-400/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Pre-Match Summary</span>
          </button>
        </div>
      </div>

      {/* Sub-Tab 1: Basic & Advanced Settings */}
      {activeSubTab === 'settings' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main 2-column Settings Column */}
          <div className="lg:col-span-2 space-y-6">
            {/* Section 59: Presets */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-semibold text-slate-100 font-cinzel">
                    Game Presets
                  </h2>
                  <p className="text-xs text-slate-400">
                    Quick-configure match pacing, difficulty, and modifier intensity.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <button
                  onClick={() => applyPreset('CASUAL')}
                  className={`p-3 rounded-lg border text-left transition-all cursor-pointer ${
                    settings.preset === 'CASUAL'
                      ? 'border-emerald-500/70 bg-emerald-950/30 text-emerald-200 shadow-md'
                      : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold text-sm text-slate-200">CASUAL</div>
                  <div className="text-[11px] text-slate-400 mt-1 leading-snug">
                    Normal creeps, bonus healing, +3 respawns, 20m timer.
                  </div>
                </button>

                <button
                  onClick={() => applyPreset('CHALLENGE')}
                  className={`p-3 rounded-lg border text-left transition-all cursor-pointer ${
                    settings.preset === 'CHALLENGE'
                      ? 'border-amber-500/70 bg-amber-950/30 text-amber-200 shadow-md'
                      : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold text-sm text-slate-200">CHALLENGE</div>
                  <div className="text-[11px] text-slate-400 mt-1 leading-snug">
                    Harder enemies, aggressive bosses, strict timers.
                  </div>
                </button>

                <button
                  onClick={() => applyPreset('CHAOS')}
                  className={`p-3 rounded-lg border text-left transition-all cursor-pointer ${
                    settings.preset === 'CHAOS'
                      ? 'border-purple-500/70 bg-purple-950/30 text-purple-200 shadow-md'
                      : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold text-sm text-purple-300 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" />
                    <span>CHAOS</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1 leading-snug">
                    Fast creeps, random elements, reduced heal, high gravity.
                  </div>
                </button>

                <button
                  onClick={() => applyPreset('CUSTOM')}
                  className={`p-3 rounded-lg border text-left transition-all cursor-pointer ${
                    settings.preset === 'CUSTOM'
                      ? 'border-cyan-500/70 bg-cyan-950/30 text-cyan-200 shadow-md'
                      : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold text-sm text-slate-200">CUSTOM</div>
                  <div className="text-[11px] text-slate-400 mt-1 leading-snug">
                    Manual fine-tuning for all match variables.
                  </div>
                </button>
              </div>
            </div>

            {/* Section 58: Basic Room Settings */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-5">
              <h2 className="text-base font-semibold text-slate-100 font-cinzel">
                Basic Match Settings
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Game Mode */}
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1.5">
                    Game Mode
                  </label>
                  <select
                    value={settings.gameMode}
                    onChange={e => {
                      setSettings(prev => ({ ...prev, gameMode: e.target.value as GameModeType, preset: 'CUSTOM' }));
                      sounds.playClick();
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-amber-500"
                  >
                    <option value="Co-Op Survival">Co-Op Survival (Wave Gauntlet)</option>
                    <option value="Boss Rush">Boss Rush (Consecutive Arch-Titans)</option>
                    <option value="Dungeon Crawl">Dungeon Crawl (Rooms & Relics)</option>
                    <option value="PvP Arena">PvP Arena (Arcane Duels)</option>
                    <option value="Elemental Trial">Elemental Trial (Resistances & Runes)</option>
                    <option value="Endless Wave">Endless Wave (Infinite Scaling)</option>
                  </select>
                </div>

                {/* Difficulty */}
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1.5">
                    Difficulty Level
                  </label>
                  <select
                    value={settings.difficulty}
                    onChange={e => {
                      setSettings(prev => ({ ...prev, difficulty: e.target.value as DifficultyLevel, preset: 'CUSTOM' }));
                      sounds.playClick();
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-amber-500"
                  >
                    <option value="Casual">Casual (Relaxed leyline energy)</option>
                    <option value="Normal">Normal (Standard Academy trial)</option>
                    <option value="Hard">Hard (Deadly strikes, high health)</option>
                    <option value="Nightmare">Nightmare (Relentless aggression)</option>
                    <option value="Mythic">Mythic (Planar apocalypse)</option>
                  </select>
                </div>

                {/* Maximum Players */}
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1.5">
                    Maximum Players ({settings.maxPlayers})
                  </label>
                  <div className="flex items-center gap-2">
                    {[2, 3, 4, 6, 8].map(count => (
                      <button
                        key={count}
                        onClick={() => {
                          setSettings(prev => ({ ...prev, maxPlayers: count, preset: 'CUSTOM' }));
                          sounds.playClick();
                        }}
                        className={`flex-1 py-1.5 text-xs font-semibold rounded-md border transition-colors cursor-pointer ${
                          settings.maxPlayers === count
                            ? 'bg-amber-400 text-slate-950 border-amber-400'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {count}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Time Limit */}
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1.5">
                    Time Limit ({settings.timeLimitMinutes === 0 ? 'Unlimited' : `${settings.timeLimitMinutes} Minutes`})
                  </label>
                  <div className="flex items-center gap-2">
                    {[5, 10, 15, 20, 0].map(mins => (
                      <button
                        key={mins}
                        onClick={() => {
                          setSettings(prev => ({ ...prev, timeLimitMinutes: mins, preset: 'CUSTOM' }));
                          sounds.playClick();
                        }}
                        className={`flex-1 py-1.5 text-xs font-semibold rounded-md border transition-colors cursor-pointer ${
                          settings.timeLimitMinutes === mins
                            ? 'bg-amber-400 text-slate-950 border-amber-400'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {mins === 0 ? '∞' : `${mins}m`}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Enemy Waves */}
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1.5">
                    Enemy Waves ({settings.enemyWaves === 0 ? 'Endless' : `${settings.enemyWaves} Waves`})
                  </label>
                  <div className="flex items-center gap-2">
                    {[5, 10, 15, 20, 0].map(waves => (
                      <button
                        key={waves}
                        onClick={() => {
                          setSettings(prev => ({ ...prev, enemyWaves: waves, preset: 'CUSTOM' }));
                          sounds.playClick();
                        }}
                        className={`flex-1 py-1.5 text-xs font-semibold rounded-md border transition-colors cursor-pointer ${
                          settings.enemyWaves === waves
                            ? 'bg-amber-400 text-slate-950 border-amber-400'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {waves === 0 ? 'Endless' : `${waves}`}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Boss Frequency */}
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1.5">
                    Boss Spawn Frequency
                  </label>
                  <div className="flex items-center gap-2">
                    {(['LOW', 'MEDIUM', 'HIGH', 'EXTREME'] as BossFrequencyType[]).map(freq => (
                      <button
                        key={freq}
                        onClick={() => {
                          setSettings(prev => ({ ...prev, bossFrequency: freq, preset: 'CUSTOM' }));
                          sounds.playClick();
                        }}
                        className={`flex-1 py-1.5 text-[11px] font-semibold rounded-md border transition-colors cursor-pointer ${
                          settings.bossFrequency === freq
                            ? 'bg-amber-400 text-slate-950 border-amber-400'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {freq}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Toggles: Friendly Fire, Team Mode, Player Respawns */}
              <div className="pt-3 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-lg">
                  <div>
                    <div className="text-xs font-semibold text-slate-200">Friendly Fire</div>
                    <div className="text-[11px] text-slate-500">Spells hit allies</div>
                  </div>
                  <button
                    onClick={() => {
                      setSettings(prev => ({ ...prev, friendlyFire: !prev.friendlyFire, preset: 'CUSTOM' }));
                      sounds.playClick();
                    }}
                    className={`px-3 py-1 text-xs font-bold rounded cursor-pointer transition-colors ${
                      settings.friendlyFire
                        ? 'bg-red-500 text-white'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {settings.friendlyFire ? 'ON' : 'OFF'}
                  </button>
                </div>

                <div className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-lg">
                  <div>
                    <div className="text-xs font-semibold text-slate-200">Team Mode</div>
                    <div className="text-[11px] text-slate-500">Shared objectives</div>
                  </div>
                  <button
                    onClick={() => {
                      setSettings(prev => ({ ...prev, teamMode: !prev.teamMode, preset: 'CUSTOM' }));
                      sounds.playClick();
                    }}
                    className={`px-3 py-1 text-xs font-bold rounded cursor-pointer transition-colors ${
                      settings.teamMode
                        ? 'bg-emerald-500 text-white'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {settings.teamMode ? 'ON' : 'OFF'}
                  </button>
                </div>

                <div className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-lg">
                  <div>
                    <div className="text-xs font-semibold text-slate-200">Player Respawns</div>
                    <div className="text-[11px] text-slate-500">Revival allowed</div>
                  </div>
                  <button
                    onClick={() => {
                      setSettings(prev => ({ ...prev, playerRespawns: !prev.playerRespawns, preset: 'CUSTOM' }));
                      sounds.playClick();
                    }}
                    className={`px-3 py-1 text-xs font-bold rounded cursor-pointer transition-colors ${
                      settings.playerRespawns
                        ? 'bg-cyan-500 text-white'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {settings.playerRespawns ? 'ON' : 'OFF'}
                  </button>
                </div>
              </div>
            </div>

            {/* Section 71: Multiplayer Weapon Balancing */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center gap-2">
                <Scale className="w-4 h-4 text-cyan-400" />
                <h2 className="text-base font-semibold text-slate-100 font-cinzel">
                  Multiplayer Weapon Balancing
                </h2>
              </div>
              <p className="text-xs text-slate-400">
                Prevent high-level players from dominating competitive lobbies, while preserving PvE progression fun.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={() => {
                    setSettings(prev => ({ ...prev, weaponBalancing: 'NORMALIZED' }));
                    sounds.playClick();
                  }}
                  className={`p-3.5 rounded-lg border text-left transition-all cursor-pointer ${
                    settings.weaponBalancing === 'NORMALIZED'
                      ? 'border-cyan-500/70 bg-cyan-950/40 text-cyan-200'
                      : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold text-xs uppercase tracking-wider text-slate-200 flex items-center justify-between">
                    <span>NORMALIZED STATS</span>
                    {settings.weaponBalancing === 'NORMALIZED' && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    Standardized combat stats for all players. Cosmetics, skins, and attack animations remain active. Ideal for competitive PvP.
                  </div>
                </button>

                <button
                  onClick={() => {
                    setSettings(prev => ({ ...prev, weaponBalancing: 'PROGRESSION' }));
                    sounds.playClick();
                  }}
                  className={`p-3.5 rounded-lg border text-left transition-all cursor-pointer ${
                    settings.weaponBalancing === 'PROGRESSION'
                      ? 'border-amber-500/70 bg-amber-950/40 text-amber-200'
                      : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="font-bold text-xs uppercase tracking-wider text-slate-200 flex items-center justify-between">
                    <span>FULL PROGRESSION</span>
                    {settings.weaponBalancing === 'PROGRESSION' && <Check className="w-3.5 h-3.5 text-amber-400" />}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    Full weapon levels (1-10) and legendary evolutions enabled. Recommended for Co-Op Survival and Boss Rushes.
                  </div>
                </button>
              </div>
            </div>

            {/* Chaos Modifiers Matrix */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-purple-400" />
                  <h3 className="text-sm font-semibold text-slate-200">
                    Chaos & Environmental Modifiers
                  </h3>
                </div>
                <span className="text-xs text-slate-500">Optional Mutators</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {[
                  { key: 'fasterEnemies', label: 'Faster Enemies (+40% Movement & Attack)' },
                  { key: 'randomElements', label: 'Random Elements (Spells shift element on cast)' },
                  { key: 'moreBosses', label: 'More Bosses (Double Arch-Titan spawns)' },
                  { key: 'reducedHealing', label: 'Reduced Healing (-60% potion/spell recovery)' },
                  { key: 'lowGravity', label: 'Low Gravity (High airtime & knockback)' },
                  { key: 'increasedSpellSpeed', label: 'Increased Spell Speed (+50% Projectile vel)' },
                  { key: 'randomEnvironmentalEvents', label: 'Random Environmental Disasters' },
                ].map(mod => {
                  const active = settings.chaosModifiers[mod.key as keyof typeof settings.chaosModifiers];
                  return (
                    <button
                      key={mod.key}
                      onClick={() => {
                        setSettings(prev => ({
                          ...prev,
                          preset: 'CUSTOM',
                          chaosModifiers: {
                            ...prev.chaosModifiers,
                            [mod.key]: !active,
                          },
                        }));
                        sounds.playClick();
                      }}
                      className={`p-2.5 rounded-lg border text-left transition-colors flex items-center justify-between cursor-pointer ${
                        active
                          ? 'bg-purple-950/40 border-purple-600/50 text-purple-200'
                          : 'bg-slate-950/60 border-slate-800/80 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <span className="pr-2 leading-tight">{mod.label}</span>
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${active ? 'bg-purple-500 text-white' : 'bg-slate-800 text-slate-500'}`}>
                        {active ? 'ON' : 'OFF'}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Column: Active Map & Unfair Setting Safeguard */}
          <div className="space-y-6">
            {/* Active Map Card */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
              <div className="relative h-44 w-full bg-slate-950">
                {selectedMap.image ? (
                  <img
                    src={selectedMap.image}
                    alt={selectedMap.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className={`w-full h-full bg-gradient-to-br ${selectedMap.themeGradient} flex items-center justify-center`}>
                    <MapPin className="w-12 h-12 text-slate-500" />
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-amber-400 font-semibold uppercase tracking-wider">
                      Active Map
                    </span>
                    <h3 className="text-lg font-bold text-white font-cinzel">
                      {selectedMap.name}
                    </h3>
                  </div>
                  <button
                    onClick={() => {
                      setActiveSubTab('map_picker');
                      sounds.playClick();
                    }}
                    className="px-2.5 py-1 text-xs font-semibold bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-200 rounded cursor-pointer"
                  >
                    Change Map
                  </button>
                </div>
              </div>

              <div className="p-4 space-y-3">
                <div>
                  <div className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-amber-400" />
                    <span>Environmental Hazard: {selectedMap.hazardName}</span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {selectedMap.hazardDetail}
                  </p>
                </div>

                <div className="text-[11px] text-slate-500 pt-2 border-t border-slate-800">
                  {selectedMap.ambientEffect}
                </div>
              </div>
            </div>

            {/* Section 58 Warning: Unfair Setting Disclosure */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                <ShieldAlert className="w-4 h-4 text-amber-400" />
                <span>Pre-Match Balance Verification</span>
              </div>

              {unfairConditions.length > 0 ? (
                <div className="space-y-2">
                  <div className="text-xs text-amber-300 font-medium">
                    The following modifiers directly affect match fairness:
                  </div>
                  <ul className="space-y-1.5">
                    {unfairConditions.map((cond, idx) => (
                      <li key={idx} className="text-xs text-slate-300 flex items-start gap-1.5 bg-amber-950/20 border border-amber-900/40 p-2 rounded">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                        <span>{cond}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="text-[11px] text-slate-500 italic">
                    Per Citadel Rule #58: All players will be prompted to acknowledge these conditions before match initiation.
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-emerald-950/20 border border-emerald-800/40 rounded-lg text-xs text-emerald-300 flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Standard balanced parameters. No unfair modifiers active.</span>
                </div>
              )}
            </div>

            {/* Start Game CTA */}
            <button
              onClick={handleStartGame}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-bold text-base rounded-xl transition-all shadow-lg hover:shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer font-cinzel"
            >
              <Flame className="w-5 h-5 text-slate-950" />
              <span>START GAME</span>
            </button>
          </div>
        </div>
      )}

      {/* Sub-Tab 2: Map Selection (Section 60) */}
      {activeSubTab === 'map_picker' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-100 font-cinzel">
                Planar Battlegrounds
              </h2>
              <p className="text-xs text-slate-400">
                Select from 9 mystical arenas, each featuring unique terrain hazards and environmental mechanics.
              </p>
            </div>
            <button
              onClick={() => setActiveSubTab('settings')}
              className="text-xs text-amber-400 hover:underline cursor-pointer"
            >
              ← Back to Room Settings
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {MAPS_LIST.map(map => {
              const isSelected = map.id === settings.mapId;
              return (
                <div
                  key={map.id}
                  onClick={() => {
                    setSettings(prev => ({ ...prev, mapId: map.id, preset: 'CUSTOM' }));
                    sounds.playClick();
                  }}
                  className={`relative rounded-xl border overflow-hidden transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? 'border-amber-400 bg-slate-900 shadow-xl ring-2 ring-amber-400/20'
                      : 'border-slate-800 bg-slate-950/70 hover:border-slate-700'
                  }`}
                >
                  {/* Map Image Banner */}
                  <div className="relative h-36 w-full bg-slate-900 overflow-hidden">
                    {map.image ? (
                      <img
                        src={map.image}
                        alt={map.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    ) : (
                      <div className={`w-full h-full bg-gradient-to-br ${map.themeGradient} flex items-center justify-center p-4 text-center`}>
                        <MapPin className="w-8 h-8 text-slate-500" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
                    <div className="absolute top-2.5 right-2.5">
                      <span className="text-[10px] font-semibold bg-slate-950/80 border border-slate-700 px-2 py-0.5 rounded text-slate-300">
                        Req. Lv. {map.recommendedLevel}
                      </span>
                    </div>
                  </div>

                  <div className="p-4 space-y-2.5 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between">
                        <h3 className="text-base font-bold text-slate-100 font-cinzel">
                          {map.name}
                        </h3>
                        {isSelected && (
                          <span className="text-xs font-bold text-amber-400 flex items-center gap-1">
                            <Check className="w-3.5 h-3.5" /> Selected
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                        {map.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800 space-y-1">
                      <div className="text-[11px] font-semibold text-amber-300 flex items-center gap-1">
                        <Flame className="w-3 h-3 text-amber-400 shrink-0" />
                        <span className="truncate">{map.hazardName}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 leading-snug">
                        {map.hazardDetail}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Sub-Tab 3: Lobby / Party Management (Section 61 & 62) */}
      {activeSubTab === 'lobby' && (
        <div className="space-y-6">
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-semibold text-slate-100 font-cinzel">
                  Party Roster ({players.length}/{settings.maxPlayers} Wizards)
                </h2>
                <p className="text-xs text-slate-400">
                  Manage connected players, kick disruptive guests, or pass host privileges.
                </p>
              </div>

              <div className="flex items-center gap-2">
                {players.length < settings.maxPlayers && (
                  <button
                    onClick={addBotPlayer}
                    className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Test Bot</span>
                  </button>
                )}

                {/* Privacy switch */}
                <div className="flex items-center gap-1 bg-slate-950 p-1 border border-slate-800 rounded-lg text-xs">
                  <button
                    onClick={() => {
                      setSettings(prev => ({ ...prev, roomType: 'PUBLIC' }));
                      sounds.playClick();
                    }}
                    className={`px-2.5 py-1 rounded cursor-pointer ${settings.roomType === 'PUBLIC' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400'}`}
                  >
                    Public
                  </button>
                  <button
                    onClick={() => {
                      setSettings(prev => ({ ...prev, roomType: 'PRIVATE' }));
                      sounds.playClick();
                    }}
                    className={`px-2.5 py-1 rounded cursor-pointer ${settings.roomType === 'PRIVATE' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400'}`}
                  >
                    Private Code
                  </button>
                  <button
                    onClick={() => {
                      setSettings(prev => ({ ...prev, roomType: 'FRIENDS_ONLY' }));
                      sounds.playClick();
                    }}
                    className={`px-2.5 py-1 rounded cursor-pointer ${settings.roomType === 'FRIENDS_ONLY' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400'}`}
                  >
                    Friends Only
                  </button>
                </div>
              </div>
            </div>

            {/* Players Table / Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {players.map(player => (
                <div
                  key={player.id}
                  className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-xl flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm text-slate-950 shadow-md"
                      style={{ backgroundColor: player.avatarColor }}
                    >
                      {player.name.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-sm text-slate-100">
                          {player.name}
                        </span>
                        {player.isHost && (
                          <span className="text-[10px] font-bold text-amber-400 bg-amber-950/50 border border-amber-800/60 px-1.5 py-0.2 rounded">
                            HOST
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                        <span>Lv. {player.level}</span>
                        <span className="text-slate-600">·</span>
                        <span className="text-amber-300 font-medium">
                          {player.staffName} ({player.isEvolved ? 'Mythic' : `+${player.staffLevel}`})
                        </span>
                        <span className="text-slate-600">·</span>
                        <span className="text-emerald-400 tabular-nums">{player.ping}ms</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold px-2 py-1 bg-emerald-950/40 border border-emerald-700/40 text-emerald-300 rounded">
                      Ready
                    </span>

                    {/* Host Controls on Player */}
                    {!player.isHost && (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => transferHost(player.id)}
                          title="Pass Host Privileges"
                          className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-slate-900 rounded cursor-pointer"
                        >
                          <Crown className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => kickPlayer(player.id)}
                          title="Kick Player from Room"
                          className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-900 rounded cursor-pointer"
                        >
                          <UserX className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 4: Pre-Match Summary (Section 59 exact format!) */}
      {activeSubTab === 'summary' && (
        <div className="max-w-2xl mx-auto bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="text-center space-y-2">
            <span className="text-xs uppercase tracking-widest text-amber-400 font-semibold">
              Multiplayer Match Confirmation
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold font-cinzel text-slate-100">
              Match Parameters Summary
            </h2>
            <p className="text-xs text-slate-400">
              Review match specifications before opening planar portal.
            </p>
          </div>

          {/* Exact format required by Section 59 */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-6 space-y-4 font-mono text-sm">
            <div className="flex justify-between items-center py-2 border-b border-slate-800/80">
              <span className="text-slate-400 font-bold">MAP:</span>
              <span className="text-amber-300 font-semibold">{selectedMap.name}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-slate-800/80">
              <span className="text-slate-400 font-bold">MODE:</span>
              <span className="text-cyan-300 font-semibold">{settings.gameMode}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-slate-800/80">
              <span className="text-slate-400 font-bold">DIFFICULTY:</span>
              <span className="text-red-400 font-semibold uppercase">{settings.difficulty}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-slate-800/80">
              <span className="text-slate-400 font-bold">PLAYERS:</span>
              <span className="text-slate-200 font-semibold">{players.length} / {settings.maxPlayers}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-slate-800/80">
              <span className="text-slate-400 font-bold">FRIENDLY FIRE:</span>
              <span className={settings.friendlyFire ? 'text-red-400 font-bold' : 'text-emerald-400 font-bold'}>
                {settings.friendlyFire ? 'ON' : 'OFF'}
              </span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-slate-800/80">
              <span className="text-slate-400 font-bold">TIME LIMIT:</span>
              <span className="text-slate-200 font-semibold">
                {settings.timeLimitMinutes === 0 ? 'UNLIMITED' : `${settings.timeLimitMinutes} MINUTES`}
              </span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-slate-800/80">
              <span className="text-slate-400 font-bold">BOSS FREQUENCY:</span>
              <span className="text-amber-400 font-bold">{settings.bossFrequency}</span>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-slate-400 font-bold">WEAPON BALANCING:</span>
              <span className="text-cyan-400 font-semibold">{settings.weaponBalancing}</span>
            </div>
          </div>

          {/* Section 58 Notice */}
          {unfairConditions.length > 0 && (
            <div className="p-3 bg-amber-950/20 border border-amber-800/50 rounded-lg text-xs text-amber-300 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Active Modifiers: </span>
                <span>{unfairConditions.join(' ')}</span>
              </div>
            </div>
          )}

          {/* Big START GAME Button as specified in Section 59 */}
          <div className="pt-2">
            <button
              onClick={handleStartGame}
              className="w-full py-4 px-6 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-lg tracking-wider rounded-xl transition-all shadow-xl hover:shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer font-cinzel"
            >
              <Flame className="w-6 h-6 text-slate-950" />
              <span>START GAME</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
