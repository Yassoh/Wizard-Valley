import React from 'react';
import { ElementType } from '../types/game';

interface WeaponVisualProps {
  element: ElementType;
  name: string;
  isEvolved?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  skinId?: string;
  className?: string;
}

export const WeaponVisual: React.FC<WeaponVisualProps> = ({
  element,
  isEvolved = false,
  size = 'md',
  skinId = 'default',
  className = '',
}) => {
  const sizeClasses = {
    sm: 'w-10 h-10',
    md: 'w-16 h-16',
    lg: 'w-24 h-24',
    xl: 'w-36 h-36',
  };

  const getElementColors = () => {
    switch (element) {
      case 'Fire':
        return {
          core: isEvolved ? '#ef4444' : '#f97316',
          glow: isEvolved ? 'rgba(239, 68, 68, 0.6)' : 'rgba(249, 115, 22, 0.4)',
          shaft: skinId === 'solar_gold' ? '#ca8a04' : '#292524',
          gem: isEvolved ? '#ff2a2a' : '#ea580c',
          particle: '#fdba74',
        };
      case 'Ice':
        return {
          core: isEvolved ? '#38bdf8' : '#7dd3fc',
          glow: isEvolved ? 'rgba(56, 189, 248, 0.7)' : 'rgba(125, 211, 252, 0.4)',
          shaft: skinId === 'black_ice' ? '#0f172a' : '#1e293b',
          gem: isEvolved ? '#0284c7' : '#38bdf8',
          particle: '#e0f2fe',
        };
      case 'Lightning':
        return {
          core: isEvolved ? '#facc15' : '#eab308',
          glow: isEvolved ? 'rgba(250, 204, 21, 0.8)' : 'rgba(234, 179, 8, 0.45)',
          shaft: skinId === 'plasma_surge' ? '#4c1d95' : '#78350f',
          gem: '#fef08a',
          particle: '#fde047',
        };
      case 'Earth':
        return {
          core: isEvolved ? '#eab308' : '#a16207',
          glow: 'rgba(161, 98, 7, 0.5)',
          shaft: skinId === 'jade_dragon' ? '#065f46' : '#451a03',
          gem: skinId === 'jade_dragon' ? '#10b981' : '#b45309',
          particle: '#fef3c7',
        };
      case 'Water':
        return {
          core: isEvolved ? '#06b6d4' : '#0891b2',
          glow: 'rgba(6, 182, 212, 0.5)',
          shaft: '#164e63',
          gem: '#22d3ee',
          particle: '#a5f3fc',
        };
      case 'Light':
        return {
          core: isEvolved ? '#fef08a' : '#fbbf24',
          glow: 'rgba(251, 191, 36, 0.7)',
          shaft: '#f8fafc',
          gem: '#ffffff',
          particle: '#fef9c3',
        };
      case 'Shadow':
        return {
          core: isEvolved ? '#c084fc' : '#a855f7',
          glow: 'rgba(168, 85, 247, 0.6)',
          shaft: '#18181b',
          gem: '#9333ea',
          particle: '#f3e8ff',
        };
      case 'Void':
        return {
          core: isEvolved ? '#ec4899' : '#d946ef',
          glow: 'rgba(236, 72, 153, 0.75)',
          shaft: '#09090b',
          gem: '#be185d',
          particle: '#fbcfe8',
        };
      case 'Ancient':
      default:
        return {
          core: isEvolved ? '#2dd4bf' : '#14b8a6',
          glow: 'rgba(20, 184, 166, 0.5)',
          shaft: '#292524',
          gem: '#5eead4',
          particle: '#ccfbf1',
        };
    }
  };

  const colors = getElementColors();

  return (
    <div className={`relative flex items-center justify-center select-none ${sizeClasses[size]} ${className}`}>
      {/* Arcane Aura Backlight */}
      <div
        className="absolute inset-0 rounded-full blur-md opacity-70 transition-all duration-300"
        style={{
          background: `radial-gradient(circle, ${colors.glow} 0%, transparent 70%)`,
          transform: isEvolved ? 'scale(1.3)' : 'scale(1)',
        }}
      />

      <svg viewBox="0 0 100 100" className="w-full h-full relative z-10 drop-shadow-md">
        {/* Staff Shaft */}
        <line
          x1="30"
          y1="82"
          x2="68"
          y2="28"
          stroke={colors.shaft}
          strokeWidth="6"
          strokeLinecap="round"
        />
        {/* Grip wrapping */}
        <line x1="42" y1="65" x2="48" y2="57" stroke="#b45309" strokeWidth="4" strokeLinecap="round" />
        <line x1="46" y1="60" x2="52" y2="52" stroke="#b45309" strokeWidth="4" strokeLinecap="round" />

        {/* Evolved Orbiting Rings / Spikes */}
        {isEvolved && (
          <>
            <circle
              cx="70"
              cy="25"
              r="18"
              fill="none"
              stroke={colors.core}
              strokeWidth="2"
              strokeDasharray="4 3"
              className="animate-spin"
              style={{ transformOrigin: '70px 25px', animationDuration: '8s' }}
            />
            <polygon
              points="70,5 73,15 67,15"
              fill={colors.particle}
              filter="drop-shadow(0 0 4px gold)"
            />
            <polygon
              points="90,25 80,28 80,22"
              fill={colors.particle}
            />
          </>
        )}

        {/* Staff Head Mount */}
        <path
          d="M 62 36 Q 66 22 75 20 Q 82 25 76 34 Z"
          fill="#334155"
          stroke={isEvolved ? 'gold' : '#64748b'}
          strokeWidth="1.5"
        />

        {/* Focal Gem */}
        <circle
          cx="71"
          cy="25"
          r={isEvolved ? "9" : "7"}
          fill={colors.gem}
          stroke={colors.particle}
          strokeWidth="1.5"
        />

        {/* Inner Glint */}
        <circle
          cx="69"
          cy="23"
          r="3"
          fill="#ffffff"
          opacity="0.8"
        />
      </svg>
    </div>
  );
};
