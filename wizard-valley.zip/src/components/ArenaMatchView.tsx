import React, { useState, useEffect, useRef } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Flame, 
  Zap, 
  Shield, 
  Skull, 
  Heart, 
  Clock, 
  AlertTriangle, 
  Trophy, 
  ArrowLeft,
  Sparkles,
  Users,
  Swords,
  Volume2,
  VolumeX,
  Palette,
  Crosshair
} from 'lucide-react';
import { RoomSettings, RoomPlayer } from '../types/game';
import { MAPS_LIST } from '../data/mapsData';
import { WEAPONS_CATALOG } from '../data/weaponsData';
import { useGameSave } from '../context/GameSaveContext';
import { sounds } from '../utils/audio';
import { CharacterCustomizerModal } from './CharacterCustomizerModal';

interface ArenaMatchViewProps {
  initialSettings?: RoomSettings;
  players?: RoomPlayer[];
  onExitToLobby: () => void;
}

// The 8 Primordial Elements matching the example
export interface PrimordialElement {
  id: string;
  name: string;
  keyNum: number;
  color: string;
  borderClass: string;
  icon: string;
  weakAgainst: string[];
  strongAgainst: string[];
  description: string;
  manaCost: number;
}

export const PRIMORDIAL_ELEMENTS: PrimordialElement[] = [
  {
    id: 'Fire',
    name: 'Fire',
    keyNum: 1,
    color: '#ef4444',
    borderClass: 'border-red-500 text-red-400',
    icon: '🔥',
    weakAgainst: ['Water'],
    strongAgainst: ['Ice', 'Earth'],
    description: 'Blazing embers that burn and melt frost defenses.',
    manaCost: 10,
  },
  {
    id: 'Water',
    name: 'Water',
    keyNum: 2,
    color: '#3b82f6',
    borderClass: 'border-blue-500 text-blue-400',
    icon: '💧',
    weakAgainst: ['Lightning', 'Ice'],
    strongAgainst: ['Fire'],
    description: 'Crashing torrents that extinguish flame and knock back.',
    manaCost: 10,
  },
  {
    id: 'Earth',
    name: 'Earth',
    keyNum: 3,
    color: '#84cc16',
    borderClass: 'border-lime-500 text-lime-400',
    icon: '🌿',
    weakAgainst: ['Fire', 'Wind'],
    strongAgainst: ['Lightning'],
    description: 'Seismic stones with high impact and grounded weight.',
    manaCost: 12,
  },
  {
    id: 'Lightning',
    name: 'Lightning',
    keyNum: 4,
    color: '#eab308',
    borderClass: 'border-yellow-500 text-yellow-400',
    icon: '⚡',
    weakAgainst: ['Earth'],
    strongAgainst: ['Water'],
    description: 'High critical chain bolts that shock conduit targets.',
    manaCost: 12,
  },
  {
    id: 'Wind',
    name: 'Wind',
    keyNum: 5,
    color: '#06b6d4',
    borderClass: 'border-cyan-500 text-cyan-400',
    icon: '💨',
    weakAgainst: ['Ice'],
    strongAgainst: ['Earth'],
    description: 'Piercing gale bursts that travel with swift velocity.',
    manaCost: 8,
  },
  {
    id: 'Ice',
    name: 'Ice',
    keyNum: 6,
    color: '#38bdf8',
    borderClass: 'border-sky-400 text-sky-300',
    icon: '❄️',
    weakAgainst: ['Fire'],
    strongAgainst: ['Wind', 'Water'],
    description: 'Glacial shards that freeze and chill enemy motion.',
    manaCost: 12,
  },
  {
    id: 'Light',
    name: 'Light',
    keyNum: 7,
    color: '#f59e0b',
    borderClass: 'border-amber-400 text-amber-300',
    icon: '✨',
    weakAgainst: ['Darkness'],
    strongAgainst: ['Darkness'],
    description: 'Pure radiant energy beam that purges corruption.',
    manaCost: 15,
  },
  {
    id: 'Darkness',
    name: 'Darkness',
    keyNum: 8,
    color: '#a855f7',
    borderClass: 'border-purple-500 text-purple-400',
    icon: '🔮',
    weakAgainst: ['Light'],
    strongAgainst: ['Light'],
    description: 'Singularity void rift that destabilizes targets.',
    manaCost: 16,
  },
];

// In-canvas entity types
interface CanvasPlayer {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  speed: number;
  dashTimer: number;
  dashCooldown: number;
  isDashing: boolean;
  angle: number;
  hp: number;
  maxHp: number;
  mana: number;
  maxMana: number;
  invulnerableTimer: number;
}

interface CanvasProjectile {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  element: string;
  color: string;
  damage: number;
  isCrit: boolean;
  fromPlayer: boolean;
  lifetime: number;
}

interface CanvasEnemy {
  id: string;
  name: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  hp: number;
  maxHp: number;
  speed: number;
  element: string;
  color: string;
  isBoss: boolean;
  attackCooldown: number;
  ranged: boolean;
  specialTimer: number;
}

interface CanvasDrop {
  id: string;
  type: 'hp' | 'mana' | 'coin' | 'crystal' | 'xp';
  x: number;
  y: number;
  value: number;
  color: string;
  icon: string;
  lifetime: number;
}

interface FloatingText {
  id: string;
  text: string;
  x: number;
  y: number;
  color: string;
  fontSize: number;
  isSuperEffective?: boolean;
  isCrit?: boolean;
  opacity: number;
  life: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  radius: number;
  life: number;
  maxLife: number;
}

interface HazardZone {
  x: number;
  y: number;
  radius: number;
  type: 'lava' | 'lightning_telegraph' | 'lightning_strike' | 'shadow_fog';
  timer: number;
  active: boolean;
}

export const ArenaMatchView: React.FC<ArenaMatchViewProps> = ({
  initialSettings,
  players = [],
  onExitToLobby,
}) => {
  const { saveData, recordMultiplayerMatch } = useGameSave();
  const [isAtelierOpen, setIsAtelierOpen] = useState(false);

  // Active settings fallback to default if launched directly
  const activeSettings: RoomSettings = initialSettings || {
    roomName: 'Citadel Proving Grounds',
    roomType: 'PUBLIC',
    roomCode: 'ARC-789',
    isLocked: false,
    gameMode: 'Co-Op Survival',
    mapId: 'crystal_caves',
    difficulty: 'Normal',
    preset: 'CASUAL',
    maxPlayers: 4,
    friendlyFire: false,
    teamMode: true,
    timeLimitMinutes: 15,
    enemyWaves: 10,
    bossFrequency: 'MEDIUM',
    playerRespawns: true,
    weaponBalancing: 'PROGRESSION',
    chaosModifiers: {
      fasterEnemies: false,
      randomElements: false,
      moreBosses: false,
      reducedHealing: false,
      lowGravity: false,
      increasedSpellSpeed: false,
      randomEnvironmentalEvents: false,
    },
  };

  const mapData = MAPS_LIST.find(m => m.id === activeSettings.mapId) || MAPS_LIST[0];
  const equippedStaff = WEAPONS_CATALOG.find(w => w.id === saveData.weapons.equippedId) || WEAPONS_CATALOG[1];
  const ownedStaffState = saveData.weapons.owned[equippedStaff.id];
  const isEvolved = ownedStaffState?.isEvolved || false;

  // Selected Active Element (default to equipped staff or Fire)
  const initialElem = PRIMORDIAL_ELEMENTS.find(e => e.id.toLowerCase() === equippedStaff.element.toLowerCase()) || PRIMORDIAL_ELEMENTS[0];
  const [activeElement, setActiveElement] = useState<PrimordialElement>(initialElem);

  // Match HUD states
  const [isPlaying, setIsPlaying] = useState(true);
  const [isGameOver, setIsGameOver] = useState(false);
  const [isVictory, setIsVictory] = useState(false);
  const [currentWave, setCurrentWave] = useState(1);
  const [score, setScore] = useState(0);
  const [kills, setKills] = useState(0);
  const [spellsCastCount, setSpellsCastCount] = useState(0);
  const [goldCollected, setGoldCollected] = useState(0);
  const [timeRemainingSeconds, setTimeRemainingSeconds] = useState(
    activeSettings.timeLimitMinutes > 0 ? activeSettings.timeLimitMinutes * 60 : 900
  );
  const [hazardAlert, setHazardAlert] = useState<string | null>(null);
  const [combatLog, setCombatLog] = useState<string[]>([
    `Arena initialized on ${mapData.name}. WASD to Move, Click to Cast, 1-8 to Switch Elements!`,
  ]);

  // Current Boss on field (for top screen boss bar)
  const [currentBoss, setCurrentBoss] = useState<CanvasEnemy | null>(null);

  // Live player stats for HUD
  const [hudHp, setHudHp] = useState(100);
  const [hudMaxHp, setHudMaxHp] = useState(100);
  const [hudMana, setHudMana] = useState(100);
  const [hudMaxMana, setHudMaxMana] = useState(100);
  const [dashReadyPercent, setDashReadyPercent] = useState(100);
  const [matchLevel, setMatchLevel] = useState(saveData.character.level);
  const [matchXp, setMatchXp] = useState(0);

  // Canvas Refs & Game Engine Loop
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // References for live 60fps states without react re-render stalls
  const gameStateRef = useRef({
    isPlaying: true,
    player: {
      x: 400,
      y: 350,
      vx: 0,
      vy: 0,
      radius: 20,
      speed: 4.8,
      dashTimer: 0,
      dashCooldown: 0,
      isDashing: false,
      angle: 0,
      hp: 100,
      maxHp: 100,
      mana: 100,
      maxMana: 100,
      invulnerableTimer: 0,
    } as CanvasPlayer,
    activeElement: initialElem,
    keys: {} as Record<string, boolean>,
    mouse: { x: 400, y: 200, isDown: false },
    projectiles: [] as CanvasProjectile[],
    enemies: [] as CanvasEnemy[],
    drops: [] as CanvasDrop[],
    floatingTexts: [] as FloatingText[],
    particles: [] as Particle[],
    hazardZones: [] as HazardZone[],
    botTeammates: [] as { x: number; y: number; name: string; color: string; shootTimer: number }[],
    lastShootTime: 0,
    currentWave: 1,
    score: 0,
    kills: 0,
    spellsCast: 0,
    gold: 0,
    matchXp: 0,
    matchLevel: saveData.character.level,
  });

  // Keep stateRef in sync with react state
  useEffect(() => {
    gameStateRef.current.activeElement = activeElement;
  }, [activeElement]);

  useEffect(() => {
    gameStateRef.current.isPlaying = isPlaying;
  }, [isPlaying]);

  // Setup simulated bot teammates if in multiplayer or team mode
  useEffect(() => {
    const bots = players
      .filter(p => !p.isHost)
      .map((p, idx) => ({
        x: 350 + idx * 80,
        y: 400 + idx * 20,
        name: p.name.split(' ')[0],
        color: p.avatarColor || '#38bdf8',
        shootTimer: 0,
      }));
    gameStateRef.current.botTeammates = bots;
  }, [players]);

  // Timer loop
  useEffect(() => {
    if (!isPlaying || isGameOver || isVictory) return;
    const interval = setInterval(() => {
      setTimeRemainingSeconds(prev => {
        if (prev <= 1) {
          handleVictory();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isPlaying, isGameOver, isVictory]);

  // Spawn Enemy Wave
  const spawnWave = (waveNum: number, width = 800, height = 500) => {
    gameStateRef.current.currentWave = waveNum;
    setCurrentWave(waveNum);

    const isBossWave = waveNum % 3 === 0 || activeSettings.bossFrequency === 'EXTREME';
    const newEnemies: CanvasEnemy[] = [];

    const creepCount = 4 + waveNum * 2;
    const elementsList = ['Fire', 'Water', 'Earth', 'Lightning', 'Wind', 'Ice', 'Darkness'];

    for (let i = 0; i < creepCount; i++) {
      // Spawn around edges
      let spawnX = Math.random() * width;
      let spawnY = Math.random() * height;
      if (Math.random() > 0.5) {
        spawnX = Math.random() > 0.5 ? 20 : width - 20;
      } else {
        spawnY = Math.random() > 0.5 ? 20 : height - 20;
      }

      const elem = elementsList[Math.floor(Math.random() * elementsList.length)];
      const elemData = PRIMORDIAL_ELEMENTS.find(e => e.id === elem) || PRIMORDIAL_ELEMENTS[0];
      const isRanged = Math.random() > 0.65;

      newEnemies.push({
        id: `creep_${waveNum}_${i}_${Date.now()}`,
        name: isRanged ? `${elem} Shaman` : `${elem} Fiend`,
        x: spawnX,
        y: spawnY,
        vx: 0,
        vy: 0,
        radius: isRanged ? 16 : 14,
        hp: 75 + waveNum * 25,
        maxHp: 75 + waveNum * 25,
        speed: activeSettings.chaosModifiers.fasterEnemies ? 2.8 : (1.4 + Math.random() * 0.8),
        element: elem,
        color: elemData.color,
        isBoss: false,
        attackCooldown: 0,
        ranged: isRanged,
        specialTimer: 0,
      });
    }

    if (isBossWave) {
      const bossElem = waveNum % 2 === 0 ? 'Darkness' : 'Fire';
      const bossData = PRIMORDIAL_ELEMENTS.find(e => e.id === bossElem) || PRIMORDIAL_ELEMENTS[0];
      const boss: CanvasEnemy = {
        id: `boss_${waveNum}_${Date.now()}`,
        name: waveNum >= 6 ? 'Titan of the Void Cataclysm' : 'Infernal Molten Behemoth',
        x: width / 2,
        y: 100,
        vx: 0,
        vy: 0,
        radius: 36,
        hp: 1200 + waveNum * 450,
        maxHp: 1200 + waveNum * 450,
        speed: 1.2,
        element: bossElem,
        color: bossData.color,
        isBoss: true,
        attackCooldown: 0,
        ranged: true,
        specialTimer: 0,
      };
      newEnemies.push(boss);
      setCurrentBoss(boss);
      sounds.playBossRoar();
      setHazardAlert(`🚨 BOSS WARNING: ${boss.name} has emerged!`);
      setCombatLog(prev => [`🚨 ${boss.name} entered the battlefield! Counter its element!`, ...prev.slice(0, 5)]);
    } else {
      setCurrentBoss(null);
    }

    gameStateRef.current.enemies = newEnemies;
  };

  const handleVictory = () => {
    setIsPlaying(false);
    setIsVictory(true);
    sounds.playEvolveFanfare();
    const finalScore = gameStateRef.current.score + 5000;
    recordMultiplayerMatch(true, finalScore, true);
  };

  const handleGameOver = () => {
    setIsPlaying(false);
    setIsGameOver(true);
    sounds.playPlayerHurt();
    recordMultiplayerMatch(false, gameStateRef.current.score, false);
  };

  const handleRestart = () => {
    sounds.playClick();
    setIsGameOver(false);
    setIsVictory(false);
    setIsPlaying(true);
    setCurrentWave(1);
    setScore(0);
    setKills(0);
    setSpellsCastCount(0);
    setGoldCollected(0);
    setTimeRemainingSeconds(activeSettings.timeLimitMinutes > 0 ? activeSettings.timeLimitMinutes * 60 : 900);

    const s = gameStateRef.current;
    s.score = 0;
    s.kills = 0;
    s.spellsCast = 0;
    s.gold = 0;
    s.projectiles = [];
    s.drops = [];
    s.floatingTexts = [];
    s.particles = [];
    s.player.hp = 100;
    s.player.mana = 100;
    s.player.x = 400;
    s.player.y = 350;
    s.player.vx = 0;
    s.player.vy = 0;
    s.player.dashCooldown = 0;

    spawnWave(1);
  };

  // Keyboard and Mouse Event Listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // 1-8 keys for element switching
      const num = parseInt(e.key, 10);
      if (num >= 1 && num <= 8) {
        const selected = PRIMORDIAL_ELEMENTS.find(el => el.keyNum === num);
        if (selected) {
          setActiveElement(selected);
          sounds.playCastSpell(selected.id);
        }
      }

      // Movement keys
      gameStateRef.current.keys[e.key.toLowerCase()] = true;

      // Space or Shift for Dash
      if (e.code === 'Space' || e.key === 'Shift') {
        e.preventDefault();
        triggerDash();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      gameStateRef.current.keys[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const triggerDash = () => {
    const p = gameStateRef.current.player;
    if (p.dashCooldown > 0) return;

    p.isDashing = true;
    p.dashTimer = 10; // frames
    p.dashCooldown = 90; // cooldown ~1.5s
    p.invulnerableTimer = 12;

    // Dash burst velocity in current facing direction
    const dashSpeed = 16;
    const moveX = (gameStateRef.current.keys['d'] || gameStateRef.current.keys['arrowright'] ? 1 : 0) -
                  (gameStateRef.current.keys['a'] || gameStateRef.current.keys['arrowleft'] ? 1 : 0);
    const moveY = (gameStateRef.current.keys['s'] || gameStateRef.current.keys['arrowdown'] ? 1 : 0) -
                  (gameStateRef.current.keys['w'] || gameStateRef.current.keys['arrowup'] ? 1 : 0);

    let angle = p.angle;
    if (moveX !== 0 || moveY !== 0) {
      angle = Math.atan2(moveY, moveX);
    }

    p.vx = Math.cos(angle) * dashSpeed;
    p.vy = Math.sin(angle) * dashSpeed;

    sounds.playDash();

    // Spawn dash particles
    for (let i = 0; i < 12; i++) {
      gameStateRef.current.particles.push({
        x: p.x + (Math.random() - 0.5) * 20,
        y: p.y + (Math.random() - 0.5) * 20,
        vx: -p.vx * 0.3 + (Math.random() - 0.5) * 2,
        vy: -p.vy * 0.3 + (Math.random() - 0.5) * 2,
        color: gameStateRef.current.activeElement.color,
        radius: 3 + Math.random() * 3,
        life: 20,
        maxLife: 20,
      });
    }
  };

  // Main Canvas 60 FPS Engine
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Resize canvas to container
    const updateCanvasSize = () => {
      if (containerRef.current && canvas) {
        canvas.width = containerRef.current.clientWidth;
        canvas.height = Math.max(480, Math.min(window.innerHeight - 260, 640));
      }
    };
    updateCanvasSize();
    window.addEventListener('resize', updateCanvasSize);

    // Initial wave spawn
    spawnWave(1, canvas.width, canvas.height);

    let animFrameId: number;

    const gameLoop = () => {
      const s = gameStateRef.current;
      const p = s.player;
      const w = canvas.width;
      const h = canvas.height;

      if (s.isPlaying) {
        // --- 1. PLAYER INPUT & MOVEMENT PHYSICS ---
        let inputX = 0;
        let inputY = 0;
        if (s.keys['w'] || s.keys['arrowup']) inputY -= 1;
        if (s.keys['s'] || s.keys['arrowdown']) inputY += 1;
        if (s.keys['a'] || s.keys['arrowleft']) inputX -= 1;
        if (s.keys['d'] || s.keys['arrowright']) inputX += 1;

        if (inputX !== 0 && inputY !== 0) {
          inputX *= 0.7071;
          inputY *= 0.7071;
        }

        // Map slippery ice mechanics if Frozen Mountains
        const isIceMap = mapData.id === 'frozen_mountains';
        const friction = isIceMap ? 0.96 : 0.82;
        const accel = isIceMap ? 0.4 : 1.2;

        if (!p.isDashing) {
          p.vx += inputX * accel;
          p.vy += inputY * accel;

          // Cap max speed
          const curSpeed = Math.hypot(p.vx, p.vy);
          if (curSpeed > p.speed) {
            p.vx = (p.vx / curSpeed) * p.speed;
            p.vy = (p.vy / curSpeed) * p.speed;
          }
        }

        p.vx *= friction;
        p.vy *= friction;
        p.x += p.vx;
        p.y += p.vy;

        // Boundaries
        p.x = Math.max(p.radius + 10, Math.min(w - p.radius - 10, p.x));
        p.y = Math.max(p.radius + 10, Math.min(h - p.radius - 10, p.y));

        // Player aim angle towards mouse
        p.angle = Math.atan2(s.mouse.y - p.y, s.mouse.x - p.x);

        // Dash cooldown & timers
        if (p.dashTimer > 0) {
          p.dashTimer--;
          if (p.dashTimer === 0) p.isDashing = false;
        }
        if (p.dashCooldown > 0) p.dashCooldown--;
        if (p.invulnerableTimer > 0) p.invulnerableTimer--;

        // Mana & HP regeneration
        p.mana = Math.min(p.maxMana, p.mana + 0.25);
        p.hp = Math.min(p.maxHp, p.hp + 0.02);

        // --- 2. PLAYER SPELL CASTING ---
        const now = Date.now();
        const baseAttackSpeed = equippedStaff.attackSpeed || 1.5;
        const attackInterval = Math.max(160, 600 / (baseAttackSpeed * (activeSettings.chaosModifiers.increasedSpellSpeed ? 1.4 : 1)));

        if (s.mouse.isDown && now - s.lastShootTime > attackInterval) {
          const currentElem = s.activeElement;
          if (p.mana >= currentElem.manaCost) {
            p.mana -= currentElem.manaCost;
            s.lastShootTime = now;
            s.spellsCast++;
            setSpellsCastCount(s.spellsCast);

            // Calculate damage based on staff level & progression
            const staffLevelBonus = (ownedStaffState?.upgradeLevel || 1) * 0.08;
            const evolvedBonus = isEvolved ? 1.4 : 1.0;
            const baseDmg = equippedStaff.baseDamage * (1 + staffLevelBonus) * evolvedBonus;
            const isCrit = Math.random() * 100 < (equippedStaff.critChance + (isEvolved ? 15 : 0));
            const finalDmg = Math.round(baseDmg * (isCrit ? 1.8 : 1.0));

            // Projectile trajectory
            const projSpeed = 9 + (equippedStaff.projectileSpeed || 10) * 0.3;
            const spread = (Math.random() - 0.5) * 0.08;
            const pAngle = p.angle + spread;

            s.projectiles.push({
              id: `proj_${Date.now()}_${Math.random()}`,
              x: p.x + Math.cos(p.angle) * (p.radius + 10),
              y: p.y + Math.sin(p.angle) * (p.radius + 10),
              vx: Math.cos(pAngle) * projSpeed,
              vy: Math.sin(pAngle) * projSpeed,
              radius: isCrit ? 7 : 5,
              element: currentElem.id,
              color: currentElem.color,
              damage: finalDmg,
              isCrit,
              fromPlayer: true,
              lifetime: 90,
            });

            sounds.playCastSpell(currentElem.id);

            // Muzzle flash particles
            for (let i = 0; i < 5; i++) {
              s.particles.push({
                x: p.x + Math.cos(p.angle) * (p.radius + 10),
                y: p.y + Math.sin(p.angle) * (p.radius + 10),
                vx: Math.cos(pAngle) * 3 + (Math.random() - 0.5) * 2,
                vy: Math.sin(pAngle) * 3 + (Math.random() - 0.5) * 2,
                color: currentElem.color,
                radius: 2.5,
                life: 14,
                maxLife: 14,
              });
            }
          }
        }

        // --- 3. BOT TEAMMATES AUTO-COMBAT ---
        s.botTeammates.forEach(bot => {
          // Roam near player
          const targetDist = 120;
          const distToPlayer = Math.hypot(p.x - bot.x, p.y - bot.y);
          if (distToPlayer > targetDist) {
            const angle = Math.atan2(p.y - bot.y, p.x - bot.x);
            bot.x += Math.cos(angle) * 2;
            bot.y += Math.sin(angle) * 2;
          }

          // Shoot nearest enemy
          bot.shootTimer++;
          if (bot.shootTimer > 60 && s.enemies.length > 0) {
            bot.shootTimer = 0;
            const target = s.enemies[0];
            const bAngle = Math.atan2(target.y - bot.y, target.x - bot.x);
            s.projectiles.push({
              id: `bot_proj_${Date.now()}_${Math.random()}`,
              x: bot.x,
              y: bot.y,
              vx: Math.cos(bAngle) * 8,
              vy: Math.sin(bAngle) * 8,
              radius: 4,
              element: 'Light',
              color: '#38bdf8',
              damage: 35,
              isCrit: false,
              fromPlayer: true,
              lifetime: 75,
            });
          }
        });

        // --- 4. PROJECTILES MOVEMENT & COLLISION ---
        s.projectiles = s.projectiles.filter(proj => {
          proj.x += proj.vx;
          proj.y += proj.vy;
          proj.lifetime--;

          // Particle trail
          if (Math.random() > 0.4) {
            s.particles.push({
              x: proj.x,
              y: proj.y,
              vx: (Math.random() - 0.5) * 0.8,
              vy: (Math.random() - 0.5) * 0.8,
              color: proj.color,
              radius: proj.radius * 0.6,
              life: 12,
              maxLife: 12,
            });
          }

          if (proj.lifetime <= 0) return false;
          if (proj.x < 0 || proj.x > w || proj.y < 0 || proj.y > h) return false;

          // Player projectile hitting enemies
          if (proj.fromPlayer) {
            for (let e of s.enemies) {
              const dist = Math.hypot(e.x - proj.x, e.y - proj.y);
              if (dist < e.radius + proj.radius) {
                // Elemental interaction calculation
                const attackingElem = PRIMORDIAL_ELEMENTS.find(el => el.id === proj.element);
                const isSuperEffective = attackingElem?.strongAgainst.includes(e.element) || false;
                const isResisted = attackingElem?.weakAgainst.includes(e.element) || false;

                let dmgMultiplier = 1.0;
                if (isSuperEffective) dmgMultiplier = 2.0;
                if (isResisted) dmgMultiplier = 0.5;

                const actualDamage = Math.round(proj.damage * dmgMultiplier);
                e.hp -= actualDamage;

                // Audio feedback
                if (isSuperEffective) {
                  sounds.playSuperEffective();
                } else {
                  sounds.playHit(proj.isCrit);
                }

                // Floating Damage Number
                s.floatingTexts.push({
                  id: `ft_${Date.now()}_${Math.random()}`,
                  text: isSuperEffective ? `${actualDamage} SUPER EFFECTIVE!` : `${actualDamage}${proj.isCrit ? ' CRIT!' : ''}`,
                  x: e.x + (Math.random() - 0.5) * 20,
                  y: e.y - 10,
                  color: isSuperEffective ? '#facc15' : (proj.isCrit ? '#fbbf24' : proj.color),
                  fontSize: isSuperEffective ? 14 : (proj.isCrit ? 15 : 12),
                  isSuperEffective,
                  isCrit: proj.isCrit,
                  opacity: 1,
                  life: 45,
                });

                // Hit spark particles
                for (let i = 0; i < 7; i++) {
                  s.particles.push({
                    x: proj.x,
                    y: proj.y,
                    vx: (Math.random() - 0.5) * 5,
                    vy: (Math.random() - 0.5) * 5,
                    color: isSuperEffective ? '#facc15' : proj.color,
                    radius: 2 + Math.random() * 2,
                    life: 16,
                    maxLife: 16,
                  });
                }

                return false; // consume projectile
              }
            }
          } else {
            // Enemy projectile hitting player
            const dist = Math.hypot(p.x - proj.x, p.y - proj.y);
            if (dist < p.radius + proj.radius) {
              if (p.invulnerableTimer <= 0 && !p.isDashing) {
                p.hp -= proj.damage;
                p.invulnerableTimer = 25;
                sounds.playPlayerHurt();

                s.floatingTexts.push({
                  id: `ft_p_${Date.now()}`,
                  text: `-${proj.damage}`,
                  x: p.x,
                  y: p.y - 15,
                  color: '#ef4444',
                  fontSize: 14,
                  opacity: 1,
                  life: 40,
                });

                if (p.hp <= 0) {
                  handleGameOver();
                }
              }
              return false;
            }
          }

          return true;
        });

        // --- 5. ENEMY AI & SPAWN MECHANICS ---
        s.enemies = s.enemies.filter(e => {
          // Check death
          if (e.hp <= 0) {
            s.kills++;
            setKills(s.kills);
            const killScore = e.isBoss ? 3500 : 250;
            s.score += killScore;
            setScore(s.score);

            // Drop items (Gold, Potions, XP)
            const dropChance = Math.random();
            if (dropChance < 0.35) {
              s.drops.push({
                id: `drop_coin_${Date.now()}_${Math.random()}`,
                type: 'coin',
                x: e.x,
                y: e.y,
                value: e.isBoss ? 250 : 25,
                color: '#facc15',
                icon: '🪙',
                lifetime: 600,
              });
            } else if (dropChance < 0.55) {
              s.drops.push({
                id: `drop_mana_${Date.now()}_${Math.random()}`,
                type: 'mana',
                x: e.x,
                y: e.y,
                value: 40,
                color: '#38bdf8',
                icon: '🧪',
                lifetime: 600,
              });
            } else if (dropChance < 0.70) {
              s.drops.push({
                id: `drop_hp_${Date.now()}_${Math.random()}`,
                type: 'hp',
                x: e.x,
                y: e.y,
                value: 30,
                color: '#ef4444',
                icon: '❤️',
                lifetime: 600,
              });
            }

            // Always drop XP gem
            s.drops.push({
              id: `drop_xp_${Date.now()}_${Math.random()}`,
              type: 'xp',
              x: e.x,
              y: e.y,
              value: e.isBoss ? 500 : 60,
              color: '#c084fc',
              icon: '💎',
              lifetime: 700,
            });

            // Death burst particles
            for (let i = 0; i < (e.isBoss ? 30 : 12); i++) {
              s.particles.push({
                x: e.x,
                y: e.y,
                vx: (Math.random() - 0.5) * 6,
                vy: (Math.random() - 0.5) * 6,
                color: e.color,
                radius: 3 + Math.random() * 3,
                life: 25,
                maxLife: 25,
              });
            }

            return false;
          }

          // Enemy movement towards player
          const distToPlayer = Math.hypot(p.x - e.x, p.y - e.y);
          const angleToPlayer = Math.atan2(p.y - e.y, p.x - e.x);

          if (e.ranged) {
            // Keep distance if ranged
            if (distToPlayer < 180) {
              e.x -= Math.cos(angleToPlayer) * e.speed;
              e.y -= Math.sin(angleToPlayer) * e.speed;
            } else if (distToPlayer > 280) {
              e.x += Math.cos(angleToPlayer) * e.speed;
              e.y += Math.sin(angleToPlayer) * e.speed;
            }

            // Fire projectile periodically
            e.attackCooldown++;
            if (e.attackCooldown > 110) {
              e.attackCooldown = 0;
              s.projectiles.push({
                id: `enemy_proj_${Date.now()}_${Math.random()}`,
                x: e.x,
                y: e.y,
                vx: Math.cos(angleToPlayer) * 4.5,
                vy: Math.sin(angleToPlayer) * 4.5,
                radius: e.isBoss ? 7 : 4,
                element: e.element,
                color: e.color,
                damage: e.isBoss ? 24 : 12,
                isCrit: false,
                fromPlayer: false,
                lifetime: 120,
              });
            }
          } else {
            // Direct charge for melee creeps
            e.x += Math.cos(angleToPlayer) * e.speed;
            e.y += Math.sin(angleToPlayer) * e.speed;

            // Melee collision damage to player
            if (distToPlayer < e.radius + p.radius) {
              if (p.invulnerableTimer <= 0 && !p.isDashing) {
                p.hp -= 15;
                p.invulnerableTimer = 30;
                sounds.playPlayerHurt();

                s.floatingTexts.push({
                  id: `ft_p_hit_${Date.now()}`,
                  text: '-15',
                  x: p.x,
                  y: p.y - 15,
                  color: '#ef4444',
                  fontSize: 14,
                  opacity: 1,
                  life: 40,
                });

                if (p.hp <= 0) handleGameOver();
              }
            }
          }

          // Boss special radial attack
          if (e.isBoss) {
            e.specialTimer++;
            if (e.specialTimer > 200) {
              e.specialTimer = 0;
              sounds.playBossRoar();
              // 8-way radial burst
              for (let a = 0; a < Math.PI * 2; a += Math.PI / 4) {
                s.projectiles.push({
                  id: `boss_radial_${Date.now()}_${a}`,
                  x: e.x,
                  y: e.y,
                  vx: Math.cos(a) * 4,
                  vy: Math.sin(a) * 4,
                  radius: 6,
                  element: e.element,
                  color: e.color,
                  damage: 18,
                  isCrit: false,
                  fromPlayer: false,
                  lifetime: 100,
                });
              }
            }
          }

          return true;
        });

        // Wave completion check
        if (s.enemies.length === 0) {
          if (activeSettings.enemyWaves > 0 && s.currentWave >= activeSettings.enemyWaves) {
            handleVictory();
          } else {
            const nextW = s.currentWave + 1;
            spawnWave(nextW, w, h);
            sounds.playUpgrade();
            setCombatLog(prev => [`Wave ${s.currentWave} cleared! Spawning Wave ${nextW}...`, ...prev.slice(0, 5)]);
          }
        }

        // --- 6. DROPS WITH MAGNETIC ATTRACTION ---
        const magnetRadius = 140;
        s.drops = s.drops.filter(drop => {
          drop.lifetime--;
          if (drop.lifetime <= 0) return false;

          const dist = Math.hypot(p.x - drop.x, p.y - drop.y);
          if (dist < magnetRadius) {
            const angle = Math.atan2(p.y - drop.y, p.x - drop.x);
            drop.x += Math.cos(angle) * 7;
            drop.y += Math.sin(angle) * 7;
          }

          // Pickup
          if (dist < p.radius + 12) {
            sounds.playPickup();
            if (drop.type === 'hp') {
              p.hp = Math.min(p.maxHp, p.hp + drop.value);
              s.floatingTexts.push({
                id: `ft_heal_${Date.now()}`,
                text: `+${drop.value} HP`,
                x: p.x,
                y: p.y - 20,
                color: '#4ade80',
                fontSize: 13,
                opacity: 1,
                life: 40,
              });
            } else if (drop.type === 'mana') {
              p.mana = Math.min(p.maxMana, p.mana + drop.value);
              s.floatingTexts.push({
                id: `ft_mana_${Date.now()}`,
                text: `+${drop.value} MP`,
                x: p.x,
                y: p.y - 20,
                color: '#38bdf8',
                fontSize: 13,
                opacity: 1,
                life: 40,
              });
            } else if (drop.type === 'coin') {
              s.gold += drop.value;
              setGoldCollected(s.gold);
              s.score += drop.value * 2;
              setScore(s.score);
            } else if (drop.type === 'xp') {
              s.matchXp += drop.value;
              setMatchXp(s.matchXp);
              if (s.matchXp >= 300) {
                s.matchXp = 0;
                s.matchLevel++;
                setMatchLevel(s.matchLevel);
                p.hp = p.maxHp;
                p.mana = p.maxMana;
                sounds.playUpgrade();
                s.floatingTexts.push({
                  id: `ft_lvl_${Date.now()}`,
                  text: 'LEVEL UP!',
                  x: p.x,
                  y: p.y - 35,
                  color: '#facc15',
                  fontSize: 18,
                  isCrit: true,
                  opacity: 1,
                  life: 60,
                });
              }
            }
            return false;
          }

          return true;
        });

        // --- 7. PARTICLES & FLOATING TEXTS ---
        s.particles = s.particles.filter(pt => {
          pt.x += pt.vx;
          pt.y += pt.vy;
          pt.life--;
          return pt.life > 0;
        });

        s.floatingTexts = s.floatingTexts.filter(ft => {
          ft.y -= 0.8;
          ft.life--;
          ft.opacity = Math.max(0, ft.life / 40);
          return ft.life > 0;
        });

        // Sync React HUD state
        setHudHp(Math.round(p.hp));
        setHudMaxHp(p.maxHp);
        setHudMana(Math.round(p.mana));
        setHudMaxMana(p.maxMana);
        setDashReadyPercent(p.dashCooldown <= 0 ? 100 : Math.round(((90 - p.dashCooldown) / 90) * 100));
      }

      // --- 8. CANVAS RENDERING (60 FPS DRAW) ---
      ctx.clearRect(0, 0, w, h);

      // Arena background grid & floor
      ctx.fillStyle = '#050811';
      ctx.fillRect(0, 0, w, h);

      // Subtle Leyline Runic Floor Grid
      ctx.strokeStyle = 'rgba(168, 85, 247, 0.08)';
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = 0; x < w; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // Central Arcane Summoning Ring
      ctx.strokeStyle = 'rgba(234, 179, 8, 0.15)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(w / 2, h / 2, 120, 0, Math.PI * 2);
      ctx.stroke();

      // Draw Drops
      s.drops.forEach(d => {
        ctx.save();
        ctx.shadowBlur = 10;
        ctx.shadowColor = d.color;
        ctx.fillStyle = d.color;
        ctx.beginPath();
        ctx.arc(d.x, d.y, 7, 0, Math.PI * 2);
        ctx.fill();
        ctx.font = '10px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(d.icon, d.x, d.y + 4);
        ctx.restore();
      });

      // Draw Particles
      s.particles.forEach(pt => {
        ctx.save();
        ctx.fillStyle = pt.color;
        ctx.globalAlpha = Math.max(0, pt.life / pt.maxLife);
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, pt.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Draw Bot Teammates
      s.botTeammates.forEach(bot => {
        ctx.save();
        ctx.fillStyle = bot.color;
        ctx.shadowBlur = 12;
        ctx.shadowColor = bot.color;
        ctx.beginPath();
        ctx.arc(bot.x, bot.y, 14, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.font = '9px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(bot.name, bot.x, bot.y - 18);
        ctx.restore();
      });

      // Draw Enemies
      s.enemies.forEach(e => {
        ctx.save();
        ctx.shadowBlur = e.isBoss ? 24 : 12;
        ctx.shadowColor = e.color;

        // Sprite / Body
        ctx.fillStyle = e.isBoss ? '#7f1d1d' : '#1e1b4b';
        ctx.strokeStyle = e.color;
        ctx.lineWidth = e.isBoss ? 4 : 2;
        ctx.beginPath();
        ctx.arc(e.x, e.y, e.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Core symbol / element icon
        ctx.fillStyle = '#ffffff';
        ctx.font = `${e.isBoss ? 20 : 12}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(e.isBoss ? '💀' : (e.ranged ? '🧙' : '👾'), e.x, e.y);

        // HP bar above enemy
        const barW = e.isBoss ? 80 : 36;
        const barH = e.isBoss ? 6 : 4;
        const barX = e.x - barW / 2;
        const barY = e.y - e.radius - 12;

        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.fillRect(barX, barY, barW, barH);
        ctx.fillStyle = e.isBoss ? '#ef4444' : e.color;
        ctx.fillRect(barX, barY, barW * (e.hp / e.maxHp), barH);

        // Name tag
        ctx.font = '10px Inter, sans-serif';
        ctx.fillStyle = '#e2e8f0';
        ctx.fillText(e.name, e.x, barY - 4);
        ctx.restore();
      });

      // Draw Projectiles
      s.projectiles.forEach(proj => {
        ctx.save();
        ctx.shadowBlur = 14;
        ctx.shadowColor = proj.color;
        ctx.fillStyle = proj.color;
        ctx.beginPath();
        ctx.arc(proj.x, proj.y, proj.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Draw Player Mage Avatar
      ctx.save();
      const charCosmetics = saveData.character;
      const robeColor = charCosmetics.robeColor || '#9333ea';
      const auraColor = charCosmetics.auraColor || '#a855f7';
      const glowRadius = charCosmetics.glowIntensity || 18;

      // Aura Glow
      ctx.shadowBlur = p.isDashing ? glowRadius * 2 : glowRadius;
      ctx.shadowColor = p.isDashing ? '#ffffff' : auraColor;

      // Invulnerability flicker
      if (p.invulnerableTimer > 0 && Math.floor(p.invulnerableTimer / 4) % 2 === 0) {
        ctx.globalAlpha = 0.5;
      }

      // Player Body Circle (Robes)
      ctx.fillStyle = robeColor;
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Wizard Staff Direction Pointer
      const staffLen = p.radius + 14;
      const staffX = p.x + Math.cos(p.angle) * staffLen;
      const staffY = p.y + Math.sin(p.angle) * staffLen;

      ctx.strokeStyle = '#78350f';
      ctx.lineWidth = 3.5;
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(staffX, staffY);
      ctx.stroke();

      // Glowing Staff Gem Tip (matches active element)
      ctx.shadowBlur = 16;
      ctx.shadowColor = s.activeElement.color;
      ctx.fillStyle = s.activeElement.color;
      ctx.beginPath();
      ctx.arc(staffX, staffY, 5, 0, Math.PI * 2);
      ctx.fill();

      // Hat Icon
      ctx.font = '14px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('🧙', p.x, p.y);

      // Player Name Floating
      ctx.font = '10px Cinzel, serif';
      ctx.fillStyle = '#f8fafc';
      ctx.fillText(saveData.character.name, p.x, p.y - p.radius - 8);

      ctx.restore();

      // Draw Floating Combat Texts
      s.floatingTexts.forEach(ft => {
        ctx.save();
        ctx.globalAlpha = ft.opacity;
        ctx.font = `bold ${ft.fontSize}px Cinzel, sans-serif`;
        ctx.fillStyle = ft.color;
        ctx.shadowBlur = 8;
        ctx.shadowColor = ft.color;
        ctx.textAlign = 'center';
        ctx.fillText(ft.text, ft.x, ft.y);
        ctx.restore();
      });

      animFrameId = requestAnimationFrame(gameLoop);
    };

    animFrameId = requestAnimationFrame(gameLoop);

    return () => {
      cancelAnimationFrame(animFrameId);
      window.removeEventListener('resize', updateCanvasSize);
    };
  }, [mapData]);

  // Mouse tracking inside canvas
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    gameStateRef.current.mouse.x = e.clientX - rect.left;
    gameStateRef.current.mouse.y = e.clientY - rect.top;
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    gameStateRef.current.mouse.isDown = true;
    handleMouseMove(e);
  };

  const handleMouseUp = () => {
    gameStateRef.current.mouse.isDown = false;
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="space-y-3 select-none">
      {/* Top HUD Console */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 sm:p-4 shadow-xl flex flex-wrap items-center justify-between gap-3">
        {/* Left: Map & Mode Details */}
        <div className="flex items-center gap-3">
          <button
            onClick={onExitToLobby}
            className="p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            title="Leave Match"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div>
            <div className="flex items-center gap-2">
              <span className="font-cinzel text-base sm:text-lg font-bold text-slate-100">
                {mapData.name}
              </span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-950/60 border border-amber-800/60 text-amber-300">
                {activeSettings.gameMode}
              </span>
            </div>
            <div className="text-xs text-slate-400 flex items-center gap-2">
              <span>Diff: <strong className="text-amber-400">{activeSettings.difficulty}</strong></span>
              <span className="text-slate-600">·</span>
              <span>Wave: <strong className="text-cyan-300">{currentWave}/{activeSettings.enemyWaves || '∞'}</strong></span>
            </div>
          </div>
        </div>

        {/* Center: Real-time Health & Mana Bars */}
        <div className="flex items-center gap-4 text-xs min-w-[240px]">
          {/* HP Bar */}
          <div className="flex-1">
            <div className="flex justify-between text-[11px] mb-1 font-semibold">
              <span className="text-red-400 flex items-center gap-1">
                <Heart className="w-3.5 h-3.5" /> HP
              </span>
              <span className="font-mono text-slate-300">{hudHp} / {hudMaxHp}</span>
            </div>
            <div className="w-full h-3 bg-slate-950 rounded-full border border-slate-700 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-red-600 to-red-400 transition-all duration-75"
                style={{ width: `${Math.max(0, (hudHp / hudMaxHp) * 100)}%` }}
              />
            </div>
          </div>

          {/* Mana Bar */}
          <div className="flex-1">
            <div className="flex justify-between text-[11px] mb-1 font-semibold">
              <span className="text-cyan-400 flex items-center gap-1">
                <Zap className="w-3.5 h-3.5" /> MANA
              </span>
              <span className="font-mono text-slate-300">{hudMana} / {hudMaxMana}</span>
            </div>
            <div className="w-full h-3 bg-slate-950 rounded-full border border-slate-700 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-600 to-blue-400 transition-all duration-75"
                style={{ width: `${Math.max(0, (hudMana / hudMaxMana) * 100)}%` }}
              />
            </div>
          </div>
        </div>

        {/* Right: Scores, Time, Atelier Customizer & Pause */}
        <div className="flex items-center gap-3 text-xs">
          <div className="text-right hidden sm:block">
            <span className="text-slate-400">Score</span>
            <div className="font-mono text-sm font-bold text-amber-400">
              {score.toLocaleString()}
            </div>
          </div>

          <div className="h-6 w-px bg-slate-800 hidden sm:block" />

          <div className="text-right">
            <span className="text-slate-400">Time</span>
            <div className="font-mono text-sm font-bold text-slate-200 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span>{formatTime(timeRemainingSeconds)}</span>
            </div>
          </div>

          {/* Character Atelier Customizer button */}
          <button
            onClick={() => {
              sounds.playClick();
              setIsAtelierOpen(true);
            }}
            className="p-2 text-purple-300 hover:text-white bg-purple-950/60 border border-purple-800/60 hover:bg-purple-900 rounded-lg cursor-pointer transition-colors"
            title="Open Wizard Atelier Customizer"
          >
            <Palette className="w-4 h-4" />
          </button>

          {/* Pause Button */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="p-2 text-slate-300 hover:text-white bg-slate-800 rounded-lg cursor-pointer ml-1"
            title={isPlaying ? 'Pause Combat' : 'Resume Combat'}
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Screen-Top Boss Health Bar (appears during boss waves) */}
      {currentBoss && currentBoss.hp > 0 && (
        <div className="bg-slate-900/90 border border-red-500/60 rounded-xl p-2.5 shadow-2xl animate-pulse">
          <div className="flex justify-between items-center text-xs font-cinzel mb-1 px-1">
            <span className="font-bold text-red-400 flex items-center gap-1.5">
              <Skull className="w-4 h-4 text-red-500 animate-spin" />
              <span>{currentBoss.name}</span>
            </span>
            <span className="font-mono font-bold text-amber-400">
              {Math.max(0, Math.round(currentBoss.hp))} / {currentBoss.maxHp} HP
            </span>
          </div>
          <div className="w-full h-3.5 bg-slate-950 rounded-full border border-red-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-red-600 via-amber-500 to-red-500 transition-all duration-100"
              style={{ width: `${Math.max(0, (currentBoss.hp / currentBoss.maxHp) * 100)}%` }}
            />
          </div>
        </div>
      )}

      {/* Main 60 FPS Canvas Battlefield Surface */}
      <div
        ref={containerRef}
        className="relative w-full rounded-2xl border-2 border-slate-800 overflow-hidden shadow-2xl bg-slate-950 cursor-crosshair"
      >
        <canvas
          ref={canvasRef}
          onMouseMove={handleMouseMove}
          onMouseDown={handleMouseDown}
          onMouseUp={handleMouseUp}
          className="w-full block"
        />

        {/* Hazard Alert Banner */}
        {hazardAlert && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-amber-950/90 border border-amber-500 text-amber-200 text-xs px-4 py-2 rounded-full shadow-2xl flex items-center gap-2 animate-bounce z-30 pointer-events-none">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="font-semibold">{hazardAlert}</span>
          </div>
        )}

        {/* Controls Overlay Prompt (Top Left) */}
        <div className="absolute top-3 left-3 z-20 text-[11px] text-slate-400 bg-slate-950/80 border border-slate-800 px-3 py-1.5 rounded-lg pointer-events-none space-y-0.5 backdrop-blur-sm">
          <div className="flex items-center gap-1.5 text-slate-200 font-semibold">
            <Crosshair className="w-3 h-3 text-amber-400" />
            <span>WASD to Move · Mouse Aim & Click to Cast</span>
          </div>
          <div className="text-[10px] text-slate-400">
            <span>[Space/Shift]: Dash · [1-8]: Switch Element</span>
          </div>
        </div>

        {/* Dash Cooldown Indicator (Bottom Left of Canvas) */}
        <div className="absolute bottom-4 left-4 z-20 bg-slate-950/80 border border-slate-800 px-3 py-1.5 rounded-lg pointer-events-none text-xs flex items-center gap-2">
          <span className="text-slate-400 font-semibold">DASH:</span>
          <div className="w-16 h-2 bg-slate-900 rounded-full overflow-hidden border border-slate-700">
            <div
              className={`h-full transition-all ${dashReadyPercent >= 100 ? 'bg-cyan-400' : 'bg-slate-500'}`}
              style={{ width: `${dashReadyPercent}%` }}
            />
          </div>
          <span className="text-[10px] font-mono text-cyan-300 font-bold">
            {dashReadyPercent >= 100 ? 'READY' : `${dashReadyPercent}%`}
          </span>
        </div>

        {/* VICTORY MODAL OVERLAY */}
        {isVictory && (
          <div className="absolute inset-0 z-40 bg-slate-950/90 backdrop-blur-sm flex items-center justify-center p-6">
            <div className="bg-slate-900 border border-amber-400 rounded-2xl max-w-md w-full p-6 text-center space-y-4 shadow-2xl ring-2 ring-amber-400/40">
              <Trophy className="w-14 h-14 text-amber-400 mx-auto animate-bounce" />
              <div>
                <span className="text-xs uppercase tracking-widest text-amber-400 font-bold">
                  TRIAL CONQUERED
                </span>
                <h3 className="text-2xl font-black text-white font-cinzel mt-1">
                  Valley Victory!
                </h3>
              </div>

              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-2">
                <div className="flex justify-between text-slate-300">
                  <span>Enemies Vanquished:</span>
                  <strong className="text-amber-400 font-mono">{kills}</strong>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Spells Cast:</span>
                  <strong className="text-cyan-300 font-mono">{spellsCastCount}</strong>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Gold Bounty Collected:</span>
                  <strong className="text-amber-300 font-mono">+{goldCollected + 1500} Coins</strong>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span>Final Score:</span>
                  <strong className="text-emerald-400 font-mono font-bold">{(score + 5000).toLocaleString()}</strong>
                </div>
                <div className="text-[10px] text-emerald-400 pt-1 border-t border-slate-800">
                  Rewards automatically synchronized to persistent Grimoire Save.
                </div>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={handleRestart}
                  className="flex-1 py-2.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-colors cursor-pointer"
                >
                  Play Again
                </button>
                <button
                  onClick={onExitToLobby}
                  className="flex-1 py-2.5 text-xs font-bold bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-lg transition-colors cursor-pointer"
                >
                  Return to Lobby
                </button>
              </div>
            </div>
          </div>
        )}

        {/* DEFEAT OVERLAY */}
        {isGameOver && (
          <div className="absolute inset-0 z-40 bg-slate-950/90 backdrop-blur-sm flex items-center justify-center p-6">
            <div className="bg-slate-900 border border-red-800 rounded-2xl max-w-md w-full p-6 text-center space-y-4 shadow-2xl">
              <Skull className="w-14 h-14 text-red-500 mx-auto" />
              <div>
                <span className="text-xs uppercase tracking-widest text-red-400 font-bold">
                  LEYLINE COLLAPSE
                </span>
                <h3 className="text-2xl font-black text-white font-cinzel mt-1">
                  Defeat in the Arena
                </h3>
              </div>

              <p className="text-xs text-slate-400">
                The magical forces proved overwhelming this time. Upgrade your staff at the Arcane Forge or counter enemy elements.
              </p>

              <div className="flex gap-3 pt-2">
                <button
                  onClick={handleRestart}
                  className="flex-1 py-2.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg transition-colors cursor-pointer"
                >
                  Retry Match
                </button>
                <button
                  onClick={onExitToLobby}
                  className="flex-1 py-2.5 text-xs font-bold bg-red-600 hover:bg-red-500 text-white rounded-lg transition-colors cursor-pointer"
                >
                  Return to Console
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 8 Primordial Elements Selector Hotbar (Matching example) */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 shadow-xl">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span className="text-xs font-bold font-cinzel text-slate-200 uppercase tracking-wider">
              Primordial Elements Hotbar
            </span>
            <span className="text-[11px] text-slate-400 hidden sm:inline">
              (Press keys 1-8 or click to switch)
            </span>
          </div>

          <div className="text-xs text-slate-400">
            Active: <strong style={{ color: activeElement.color }}>{activeElement.name}</strong> · Mana Cost: <strong className="text-cyan-300">{activeElement.manaCost} MP</strong>
          </div>
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
          {PRIMORDIAL_ELEMENTS.map(elem => {
            const isActive = activeElement.id === elem.id;
            return (
              <button
                key={elem.id}
                onClick={() => {
                  setActiveElement(elem);
                  sounds.playCastSpell(elem.id);
                }}
                className={`p-2 rounded-xl border flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                  isActive
                    ? 'border-amber-400 bg-amber-500/15 scale-105 shadow-lg ring-2 ring-amber-400/40 text-white'
                    : 'border-slate-800 bg-slate-950/60 hover:border-slate-700 text-slate-400 hover:text-slate-200'
                }`}
                style={{
                  boxShadow: isActive ? `0 0 16px ${elem.color}50` : undefined,
                }}
              >
                <div className="flex items-center justify-between w-full text-[10px] px-1">
                  <span className="font-mono font-bold text-slate-400">[{elem.keyNum}]</span>
                  <span className="text-base">{elem.icon}</span>
                </div>
                <span className="text-xs font-bold font-cinzel truncate">{elem.name}</span>
                <span className="text-[9px] text-slate-500 hidden sm:block truncate">
                  vs {elem.strongAgainst[0]}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Character Customizer Modal */}
      <CharacterCustomizerModal
        isOpen={isAtelierOpen}
        onClose={() => setIsAtelierOpen(false)}
      />
    </div>
  );
};
