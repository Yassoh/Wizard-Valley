import React, { useState } from 'react';
import { BookOpen, Gift, Lock, Check, Sparkles, HelpCircle, Shield, ArrowRight, ArrowLeft } from 'lucide-react';
import { WEAPONS_CATALOG } from '../data/weaponsData';
import { WeaponVisual } from './WeaponVisual';
import { useGameSave } from '../context/GameSaveContext';
import { sounds } from '../utils/audio';

const MILESTONES = [
  { count: 3, label: '3 Weapons Discovered', rewardCoins: 1500, rewardCores: 1, title: 'Citadel Initiate' },
  { count: 5, label: '5 Weapons Discovered', rewardCoins: 5000, rewardCores: 2, title: 'Elemental Adept' },
  { count: 8, label: '8 Weapons Discovered', rewardCoins: 12000, rewardCores: 4, title: 'Master Forger' },
  { count: 10, label: '10 Weapons (Full Arsenal)', rewardCoins: 30000, rewardCores: 8, title: 'Grand Archon of Citadels' },
];

interface WeaponCollectionViewProps {
  onBackToMenu?: () => void;
}

export const WeaponCollectionView: React.FC<WeaponCollectionViewProps> = ({ onBackToMenu }) => {
  const { saveData, claimCollectionReward } = useGameSave();
  const [selectedCodexId, setSelectedCodexId] = useState<string>('flame_staff');

  const discoveredSet = new Set(saveData.collections.weaponsDiscovered);
  const discoveredCount = discoveredSet.size;

  const selectedWeapon = WEAPONS_CATALOG.find(w => w.id === selectedCodexId) || WEAPONS_CATALOG[0];
  const isSelectedDiscovered = discoveredSet.has(selectedWeapon.id);
  const ownedState = saveData.weapons.owned[selectedWeapon.id];

  return (
    <div className="space-y-6">
      {/* Header & Collection Milestones */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-6 shadow-xl space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            {onBackToMenu && (
              <button
                onClick={() => {
                  sounds.playClick();
                  onBackToMenu();
                }}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-amber-300 bg-slate-950/80 hover:bg-slate-900 border border-slate-800 px-3 py-1 rounded-lg transition-colors cursor-pointer mb-2"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>← Main Menu</span>
              </button>
            )}
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-widest">
              <BookOpen className="w-4 h-4 text-amber-400" />
              <span>Imperial Grand Arsenal Codex</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold font-cinzel text-slate-100 mt-1">
              Weapon Collection ({discoveredCount}/{WEAPONS_CATALOG.length} Discovered)
            </h1>
            <p className="text-xs sm:text-sm text-slate-400">
              Archival grimoire documenting all known magical staves across the 9 planar domains.
            </p>
          </div>

          {/* Progress Bar */}
          <div className="min-w-[220px]">
            <div className="flex justify-between text-xs text-slate-400 mb-1.5">
              <span>Collection Mastery</span>
              <span className="font-mono font-bold text-amber-400">
                {Math.round((discoveredCount / WEAPONS_CATALOG.length) * 100)}%
              </span>
            </div>
            <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-amber-300 transition-all duration-500"
                style={{ width: `${(discoveredCount / WEAPONS_CATALOG.length) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Collection Rewards Track */}
        <div className="pt-4 border-t border-slate-800 space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
            <Gift className="w-4 h-4 text-amber-400" />
            <span>Arsenal Milestone Bounties</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {MILESTONES.map(m => {
              const achieved = discoveredCount >= m.count;
              const claimed = saveData.collections.claimedMilestones.includes(m.count);

              return (
                <div
                  key={m.count}
                  className={`p-3 rounded-lg border flex flex-col justify-between ${
                    claimed
                      ? 'bg-slate-950/60 border-slate-800/80 text-slate-500'
                      : achieved
                      ? 'bg-amber-950/30 border-amber-500/60 text-amber-200 shadow-md'
                      : 'bg-slate-950/40 border-slate-800 text-slate-500'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between text-xs font-bold">
                      <span className={achieved ? 'text-slate-200' : 'text-slate-400'}>
                        {m.label}
                      </span>
                      {claimed && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-1">
                      Reward: +{m.rewardCoins.toLocaleString()} Coins · {m.rewardCores} Cores
                    </div>
                  </div>

                  <div className="mt-2.5 pt-2 border-t border-slate-800/60">
                    {claimed ? (
                      <span className="text-[10px] text-emerald-400 font-semibold uppercase">
                        Bounty Claimed
                      </span>
                    ) : (
                      <button
                        onClick={() => claimCollectionReward(m.count, m.rewardCoins, m.rewardCores)}
                        disabled={!achieved}
                        className={`w-full py-1 text-[11px] font-bold rounded cursor-pointer transition-colors ${
                          achieved
                            ? 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow'
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        }`}
                      >
                        {achieved ? 'Claim Reward' : `Locked (${discoveredCount}/${m.count})`}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Weapons Codex Grid & Selected Detailed Entry */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Weapons Grid (7 cols) */}
        <div className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-3 gap-3">
          {WEAPONS_CATALOG.map(weapon => {
            const isDiscovered = discoveredSet.has(weapon.id);
            const isSelected = weapon.id === selectedWeapon.id;
            const owned = saveData.weapons.owned[weapon.id];

            return (
              <div
                key={weapon.id}
                onClick={() => {
                  setSelectedCodexId(weapon.id);
                  sounds.playClick();
                }}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col items-center text-center justify-between min-h-[160px] ${
                  isSelected
                    ? 'bg-slate-900 border-amber-400 shadow-xl ring-2 ring-amber-400/20'
                    : isDiscovered
                    ? 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                    : 'bg-slate-950/40 border-slate-900 text-slate-600 hover:border-slate-800'
                }`}
              >
                {isDiscovered ? (
                  <>
                    <WeaponVisual
                      element={weapon.element}
                      name={weapon.name}
                      isEvolved={owned?.isEvolved}
                      size="md"
                    />
                    <div className="mt-2">
                      <div className="text-xs font-bold text-slate-200 font-cinzel line-clamp-1">
                        {owned?.isEvolved ? (weapon.evolvedName || weapon.name) : weapon.name}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5" style={{ color: weapon.themeColor }}>
                        {weapon.element} School
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="w-16 h-16 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-600">
                      <HelpCircle className="w-8 h-8 opacity-40" />
                    </div>
                    <div className="mt-2">
                      <div className="text-xs font-bold text-slate-500 font-cinzel">
                        ???
                      </div>
                      <div className="text-[10px] text-slate-600">
                        Undiscovered Staff
                      </div>
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>

        {/* Right: Selected Weapon Deep Dive Codex Page (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
          {isSelectedDiscovered ? (
            <>
              <div className="flex items-center gap-4">
                <WeaponVisual
                  element={selectedWeapon.element}
                  name={selectedWeapon.name}
                  isEvolved={ownedState?.isEvolved}
                  skinId={ownedState?.selectedSkin}
                  size="lg"
                />
                <div>
                  <span
                    className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded"
                    style={{ backgroundColor: `${selectedWeapon.themeColor}20`, color: selectedWeapon.themeColor }}
                  >
                    {selectedWeapon.element} School
                  </span>
                  <h3 className="text-xl font-bold text-slate-100 font-cinzel mt-1">
                    {ownedState?.isEvolved ? selectedWeapon.evolvedName : selectedWeapon.name}
                  </h3>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Acquisition: {ownedState ? `Owned (Upgrade ${ownedState.upgradeLevel}/10)` : 'Catalogued'}
                  </div>
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <div>
                  <h4 className="text-xs font-bold text-slate-300">Description</h4>
                  <p className="text-xs text-slate-400 leading-relaxed mt-0.5">
                    {selectedWeapon.description}
                  </p>
                </div>

                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs italic text-amber-200/80 leading-relaxed">
                  {selectedWeapon.flavorLore}
                </div>

                {/* Stats Table */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-slate-950 p-2 rounded border border-slate-800/80">
                    <span className="text-slate-500 text-[10px]">Base Damage</span>
                    <div className="font-bold text-slate-200 font-mono">
                      {selectedWeapon.baseDamage}
                    </div>
                  </div>
                  <div className="bg-slate-950 p-2 rounded border border-slate-800/80">
                    <span className="text-slate-500 text-[10px]">Attack Velocity</span>
                    <div className="font-bold text-slate-200 font-mono">
                      {selectedWeapon.attackSpeed}/sec
                    </div>
                  </div>
                  <div className="bg-slate-950 p-2 rounded border border-slate-800/80">
                    <span className="text-slate-500 text-[10px]">Critical Chance</span>
                    <div className="font-bold text-slate-200 font-mono">
                      {selectedWeapon.critChance}%
                    </div>
                  </div>
                  <div className="bg-slate-950 p-2 rounded border border-slate-800/80">
                    <span className="text-slate-500 text-[10px]">Elemental Power</span>
                    <div className="font-bold text-slate-200 font-mono">
                      +{selectedWeapon.elementalPower}%
                    </div>
                  </div>
                </div>

                {/* How it was obtained */}
                <div className="pt-2 border-t border-slate-800">
                  <span className="text-xs font-bold text-amber-300">How Obtained:</span>
                  <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                    {selectedWeapon.howObtained}
                  </p>
                </div>

                {/* Evolution preview */}
                {selectedWeapon.evolvedName && (
                  <div className="p-3 bg-purple-950/20 border border-purple-800/40 rounded-lg text-xs space-y-1">
                    <div className="font-bold text-purple-300 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Evolution: {selectedWeapon.evolvedName}</span>
                    </div>
                    <p className="text-slate-400 leading-snug">
                      {selectedWeapon.evolvedSpecialEffect}
                    </p>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="text-center py-12 space-y-4">
              <div className="w-20 h-20 rounded-full bg-slate-950 border border-slate-800 flex items-center justify-center mx-auto text-slate-600">
                <Lock className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-slate-400 font-cinzel">
                  Undiscovered Artifact
                </h3>
                <p className="text-xs text-slate-500 max-w-xs mx-auto">
                  This magical staff remains hidden in uncharted dungeons or boss sanctums. Venture into deeper planar portals to discover it.
                </p>
              </div>
              <div className="text-xs text-amber-400 bg-amber-950/20 border border-amber-900/40 p-2.5 rounded-lg inline-block">
                Discovery Hint: Defeat guardians in high difficulty multiplayer or deep dungeons.
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
