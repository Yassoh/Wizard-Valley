export interface ElementDefinition {
  id: number;
  name: string;
  color: string;
  glow: string;
  icon: string;
  strongAgainst: number;
  desc: string;
}

export const ELEMENTS_WHEEL: ElementDefinition[] = [
  { id: 0, name: 'Fire', color: '#ef4444', glow: 'rgba(239,68,68,0.5)', icon: 'fa-fire', strongAgainst: 5, desc: 'High explosive damage. Strong vs Ice.' },
  { id: 1, name: 'Water', color: '#3b82f6', glow: 'rgba(59,130,246,0.5)', icon: 'fa-droplet', strongAgainst: 0, desc: 'Fast water bolts. Strong vs Fire.' },
  { id: 2, name: 'Earth', color: '#84cc16', glow: 'rgba(132,204,22,0.5)', icon: 'fa-mountain', strongAgainst: 4, desc: 'Heavy piercing boulders. Strong vs Lightning.' },
  { id: 3, name: 'Air', color: '#06b6d4', glow: 'rgba(6,182,212,0.5)', icon: 'fa-wind', strongAgainst: 2, desc: 'Rapid gusts & pushback. Strong vs Earth.' },
  { id: 4, name: 'Lightning', color: '#eab308', glow: 'rgba(234,179,8,0.5)', icon: 'fa-bolt', strongAgainst: 1, desc: 'High speed zaps. Strong vs Water.' },
  { id: 5, name: 'Ice', color: '#38bdf8', glow: 'rgba(56,189,248,0.5)', icon: 'fa-snowflake', strongAgainst: 3, desc: 'Slows & freezes targets. Strong vs Air.' },
  { id: 6, name: 'Shadow', color: '#a855f7', glow: 'rgba(168,85,247,0.5)', icon: 'fa-skull', strongAgainst: 7, desc: 'Dark bolts with life siphon. Strong vs Light.' },
  { id: 7, name: 'Light', color: '#f59e0b', glow: 'rgba(245,158,11,0.5)', icon: 'fa-sun', strongAgainst: 6, desc: 'Radiant beams with bonus damage. Strong vs Shadow.' }
];
