export interface AccessoryItem {
  id: string;
  name: string;
  cost: number;
  icon: string;
}

export const ACCESSORIES_SHOP: Record<'hat' | 'staff' | 'back' | 'trail', AccessoryItem[]> = {
  hat: [
    { id: 'hat_cap', name: 'Wizard Cap', cost: 0, icon: 'fa-hat-wizard' },
    { id: 'hat_crown', name: 'Archmage Crown', cost: 150, icon: 'fa-crown' },
    { id: 'hat_helm', name: 'Elemental Helm', cost: 250, icon: 'fa-helmet-safety' },
    { id: 'hat_horns', name: 'Void Horns', cost: 350, icon: 'fa-spaghetti-monster-flying' },
    { id: 'hat_halo', name: 'Holy Halo', cost: 500, icon: 'fa-sun' },
  ],
  staff: [
    { id: 'staff_arcane', name: 'Arcane Staff', cost: 0, icon: 'fa-wand-magic' },
    { id: 'staff_wand', name: 'Crystal Wand', cost: 120, icon: 'fa-wand-sparkles' },
    { id: 'staff_scythe', name: 'Phoenix Scythe', cost: 300, icon: 'fa-disease' },
    { id: 'staff_void', name: 'Void Staff', cost: 450, icon: 'fa-wand-magic-sparkles' },
  ],
  back: [
    { id: 'back_none', name: 'None', cost: 0, icon: 'fa-ban' },
    { id: 'back_orbs', name: 'Floating Orbs', cost: 200, icon: 'fa-circle-nodes' },
    { id: 'back_pet', name: 'Familiar Pet', cost: 400, icon: 'fa-cat' },
    { id: 'back_archangel', name: 'Archangel Wings', cost: 450, icon: 'fa-feather-pointed' },
    { id: 'back_dragon', name: 'Dragon Wings', cost: 500, icon: 'fa-dragon' },
  ],
  trail: [
    { id: 'trail_stardust', name: 'Star Dust', cost: 0, icon: 'fa-star' },
    { id: 'trail_flames', name: 'Elemental Flames', cost: 150, icon: 'fa-fire' },
    { id: 'trail_shadow', name: 'Shadow Smoke', cost: 250, icon: 'fa-smog' },
    { id: 'trail_rainbow', name: 'Rainbow Glider', cost: 400, icon: 'fa-rainbow' },
  ],
};

export function drawWizardAvatarCanvas(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number,
  angle: number,
  data: {
    name?: string;
    robeColor?: string;
    auraColor?: string;
    glowIntensity?: number;
    hat?: string;
    staffVisual?: string;
    back?: string;
  }
) {
  if (!data) return;
  ctx.save();
  ctx.translate(x, y);

  const glowIntensity = data.glowIntensity || 15;
  const auraColor = data.auraColor || '#a855f7';
  const robeColor = data.robeColor || '#9333ea';
  const name = data.name || 'Wizard';

  // Aura Glow
  ctx.beginPath();
  ctx.arc(0, 0, radius + glowIntensity * 0.5, 0, Math.PI * 2);
  ctx.fillStyle = auraColor;
  ctx.globalAlpha = 0.25;
  ctx.fill();
  ctx.globalAlpha = 1.0;

  // Back Accessories (Wings / Orbs / Pet)
  if (data.back === 'back_dragon') {
    ctx.fillStyle = '#ef4444';
    ctx.beginPath(); ctx.moveTo(-radius, -10); ctx.lineTo(-radius - 30, -25); ctx.lineTo(-radius - 15, 10); ctx.fill();
    ctx.beginPath(); ctx.moveTo(radius, -10); ctx.lineTo(radius + 30, -25); ctx.lineTo(radius + 15, 10); ctx.fill();
  } else if (data.back === 'back_archangel') {
    ctx.fillStyle = '#fef08a';
    ctx.beginPath(); ctx.moveTo(-radius, -5); ctx.lineTo(-radius - 32, -30); ctx.lineTo(-radius - 10, 15); ctx.fill();
    ctx.beginPath(); ctx.moveTo(radius, -5); ctx.lineTo(radius + 32, -30); ctx.lineTo(radius + 10, 15); ctx.fill();
  } else if (data.back === 'back_orbs') {
    ctx.fillStyle = '#06b6d4';
    ctx.beginPath(); ctx.arc(-radius - 12, -15, 6, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(radius + 12, -15, 6, 0, Math.PI * 2); ctx.fill();
  } else if (data.back === 'back_pet') {
    ctx.fillStyle = '#a855f7';
    ctx.beginPath(); ctx.arc(radius + 18, 15, 8, 0, Math.PI * 2); ctx.fill();
  }

  // Robe Body
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.fillStyle = robeColor;
  ctx.fill();
  ctx.lineWidth = 3;
  ctx.strokeStyle = '#eab308';
  ctx.stroke();

  // Staff
  ctx.save();
  ctx.rotate(angle);
  ctx.strokeStyle = '#854d0e';
  ctx.lineWidth = 4;
  ctx.beginPath(); ctx.moveTo(radius * 0.5, -radius * 0.5); ctx.lineTo(radius * 1.3, -radius * 1.3); ctx.stroke();

  if (data.staffVisual === 'staff_wand') {
    ctx.fillStyle = '#38bdf8';
    ctx.beginPath(); ctx.arc(radius * 1.3, -radius * 1.3, 6, 0, Math.PI * 2); ctx.fill();
  } else if (data.staffVisual === 'staff_scythe') {
    ctx.fillStyle = '#f87171';
    ctx.beginPath(); ctx.arc(radius * 1.3, -radius * 1.3, 8, 0, Math.PI * 2); ctx.fill();
  } else {
    ctx.fillStyle = '#eab308';
    ctx.beginPath(); ctx.arc(radius * 1.3, -radius * 1.3, 7, 0, Math.PI * 2); ctx.fill();
  }
  ctx.restore();

  // Hat / Helmet
  if (data.hat === 'hat_crown') {
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.moveTo(-15, -radius + 4);
    ctx.lineTo(-15, -radius - 14); ctx.lineTo(-7, -radius - 6); ctx.lineTo(0, -radius - 18);
    ctx.lineTo(7, -radius - 6); ctx.lineTo(15, -radius - 14); ctx.lineTo(15, -radius + 4);
    ctx.fill();
  } else if (data.hat === 'hat_halo') {
    ctx.strokeStyle = '#fef08a';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(0, -radius - 12, 14, 5, 0, 0, Math.PI * 2);
    ctx.stroke();
  } else if (data.hat === 'hat_horns') {
    ctx.fillStyle = '#c084fc';
    ctx.beginPath(); ctx.moveTo(-10, -radius + 4); ctx.quadraticCurveTo(-22, -radius - 20, -18, -radius - 22); ctx.fill();
    ctx.beginPath(); ctx.moveTo(10, -radius + 4); ctx.quadraticCurveTo(22, -radius - 20, 18, -radius - 22); ctx.fill();
  } else {
    // Default Wizard Cap
    ctx.fillStyle = '#3b0764';
    ctx.beginPath();
    ctx.moveTo(-18, -radius + 6);
    ctx.lineTo(0, -radius - 24);
    ctx.lineTo(18, -radius + 6);
    ctx.fill();
  }

  // Name Tag overhead
  ctx.fillStyle = '#fde047';
  ctx.font = 'bold 11px Inter, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(name, 0, -radius - 26);

  ctx.restore();
}
