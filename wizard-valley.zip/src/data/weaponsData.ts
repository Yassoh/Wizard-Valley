import { WeaponItem, MaterialKey, ElementType } from '../types/game';

export interface UpgradeCost {
  coins: number;
  magicDust: number;
  crystals: { key: MaterialKey; amount: number }[];
}

export function getUpgradeCost(currentLevel: number, element: ElementType): UpgradeCost {
  // Level 0 -> 1 up to Level 9 -> 10
  const lvl = currentLevel + 1;
  const baseCoins = 250 * lvl * (lvl > 5 ? 1.5 : 1);
  const baseDust = 10 * lvl;
  
  let crystalKey: MaterialKey = 'magic_dust';
  if (element === 'Fire') crystalKey = 'fire_crystal';
  else if (element === 'Ice') crystalKey = 'ice_crystal';
  else if (element === 'Lightning') crystalKey = 'storm_crystal';
  else if (element === 'Earth') crystalKey = 'earth_crystal';
  else if (element === 'Shadow') crystalKey = 'shadow_fragment';
  else if (element === 'Light') crystalKey = 'light_fragment';
  else if (element === 'Ancient') crystalKey = 'ancient_core';
  else if (element === 'Void') crystalKey = 'void_crystal';
  else crystalKey = 'magic_dust';

  const crystalAmount = Math.max(1, Math.floor(lvl / 2));
  const rareCores = lvl >= 8 ? [{ key: 'ancient_core' as MaterialKey, amount: lvl === 10 ? 3 : 1 }] : [];

  return {
    coins: Math.round(baseCoins),
    magicDust: Math.round(baseDust),
    crystals: [
      { key: crystalKey, amount: crystalAmount },
      ...rareCores,
    ],
  };
}

export function getEvolutionCost(weapon: WeaponItem): UpgradeCost {
  let primaryCrystal: MaterialKey = 'void_crystal';
  if (weapon.element === 'Fire') primaryCrystal = 'fire_crystal';
  if (weapon.element === 'Ice') primaryCrystal = 'ice_crystal';
  if (weapon.element === 'Lightning') primaryCrystal = 'storm_crystal';
  if (weapon.element === 'Earth') primaryCrystal = 'earth_crystal';
  if (weapon.element === 'Shadow') primaryCrystal = 'shadow_fragment';
  if (weapon.element === 'Light') primaryCrystal = 'light_fragment';

  return {
    coins: 10000,
    magicDust: 200,
    crystals: [
      { key: primaryCrystal, amount: 8 },
      { key: 'ancient_core', amount: 4 },
      { key: 'void_crystal', amount: 2 },
    ],
  };
}

export const WEAPONS_CATALOG: WeaponItem[] = [
  {
    id: 'apprentice_staff',
    name: 'Apprentice Staff',
    element: 'Ancient',
    levelReq: 1,
    baseDamage: 45,
    attackSpeed: 1.8,
    projectileSpeed: 120,
    critChance: 5,
    elementalPower: 10,
    manaEfficiency: 85,
    specialEffect: 'Balanced mana channel. Casting spells consumes 5% less mana.',
    evolvedId: 'archmage_rod',
    evolvedName: 'Archmage Genesis Rod',
    evolvedSpecialEffect: 'Unleashes harmonic triple bolts with 15% chance to refund full mana cost.',
    evolvedDamageBonus: 65,
    description: 'A finely sanded ashwood staff crowned with a pure quartz focus. The trusted companion of every aspiring wizard.',
    flavorLore: 'Handed to initiates at the Academy gates, this staff teaches steady spell control before elemental specialization.',
    howObtained: 'Starter gift from Headmaster Varis in Wizard Village.',
    themeColor: '#94a3b8',
    accentGlow: 'rgba(148, 163, 184, 0.4)',
    attackAnimation: 'arcane-beam',
    availableSkins: [
      { id: 'default', name: 'Academy Ashwood', visualDesc: 'Classic polished ashwood finish.' },
      { id: 'silver_carved', name: 'Silver Inscribed', visualDesc: 'Silver foil runes carved into the shaft.' },
      { id: 'ancient_bark', name: 'Ironwood Relic', visualDesc: 'Petrified ironwood with faint teal pulse.' },
    ],
  },
  {
    id: 'flame_staff',
    name: 'Flame Staff',
    element: 'Fire',
    levelReq: 5,
    baseDamage: 72,
    attackSpeed: 1.5,
    projectileSpeed: 110,
    critChance: 12,
    elementalPower: 25,
    manaEfficiency: 70,
    specialEffect: 'Incinerate: Attacks have a 35% chance to burn enemies for 40% damage over 3 seconds.',
    evolvedId: 'inferno_staff',
    evolvedName: 'Inferno Staff',
    evolvedSpecialEffect: 'Cataclysmic Flare: Burn spreads to nearby enemies. Slain burning enemies explode in a firestorm.',
    evolvedDamageBonus: 95,
    description: 'Forged within the geothermal fissures of the Volcano, tipped with an unquenchable ruby hearth.',
    flavorLore: '"To hold fire is to hold a wild beast by its throat. Squeeze too hard, it bites; slacken, it consumes you."',
    howObtained: 'Defeat the Molten Hearthkeeper in the Volcano Depths (or craft at Arcane Forge).',
    themeColor: '#f97316',
    accentGlow: 'rgba(249, 115, 22, 0.5)',
    attackAnimation: 'fireball-cascade',
    availableSkins: [
      { id: 'default', name: 'Magma Core', visualDesc: 'Blackened obsidian shaft with crackling orange veins.' },
      { id: 'solar_gold', name: 'Solaris Gilded', visualDesc: 'Gilded sun crest with radiant golden flame plume.' },
      { id: 'crimson_cinder', name: 'Cinder Ashen', visualDesc: 'Deep crimson wood trailing floating volcanic embers.' },
    ],
  },
  {
    id: 'frost_staff',
    name: 'Frost Staff',
    element: 'Ice',
    levelReq: 5,
    baseDamage: 68,
    attackSpeed: 1.6,
    projectileSpeed: 130,
    critChance: 8,
    elementalPower: 24,
    manaEfficiency: 78,
    specialEffect: 'Deep Chill: Attacks slow enemy movement and attack velocity by 30% for 3 seconds.',
    evolvedId: 'glacial_staff',
    evolvedName: 'Glacial Staff',
    evolvedSpecialEffect: 'Absolute Zero: Consecutive hits freeze targets solid for 2.5s. Shattering deals massive area critical damage.',
    evolvedDamageBonus: 90,
    description: 'Hewn from evergreen permafrost ice found at the peak of the Frozen Mountains.',
    flavorLore: 'The chill numbs the hands of the unworthy, while true cryomancers hear the quiet song of crystallized silence.',
    howObtained: 'Recover the Frozen Shard from Glacial Wyrm in the Frozen Mountains.',
    themeColor: '#38bdf8',
    accentGlow: 'rgba(56, 189, 248, 0.5)',
    attackAnimation: 'glacial-shard',
    availableSkins: [
      { id: 'default', name: 'Permafrost Spire', visualDesc: 'Translucent blue rime with crystalline branches.' },
      { id: 'aurora_borealis', name: 'Aurora Loom', visualDesc: 'Glows with shifting emerald and cyan polar lights.' },
      { id: 'black_ice', name: 'Black Glacier', visualDesc: 'Opaque dark ice emitting frosty mist.' },
    ],
  },
  {
    id: 'storm_staff',
    name: 'Storm Staff',
    element: 'Lightning',
    levelReq: 10,
    baseDamage: 84,
    attackSpeed: 2.1,
    projectileSpeed: 180,
    critChance: 18,
    elementalPower: 30,
    manaEfficiency: 65,
    specialEffect: 'Chain Arc: Lightning attacks have a 45% chance to chain between up to 3 additional enemies.',
    evolvedId: 'tempest_staff',
    evolvedName: 'Tempest Staff',
    evolvedSpecialEffect: 'Thunder God Wrath: Chains jump up to 6 targets with zero damage falloff, triggering localized lightning strikes.',
    evolvedDamageBonus: 110,
    description: 'Tethered to the upper stratus clouds, drawing kinetic lightning directly into its conductible coil head.',
    flavorLore: 'Sparks jump from the caster’s fingertips even when at rest. Handle only during thunderous tempests.',
    howObtained: 'Harvest the Storm Core during Sky Kingdom lightning vortex event.',
    themeColor: '#eab308',
    accentGlow: 'rgba(234, 179, 8, 0.5)',
    attackAnimation: 'storm-chain',
    availableSkins: [
      { id: 'default', name: 'Voltaic Conduit', visualDesc: 'Copper wire coils orbiting a levitating storm crystal.' },
      { id: 'plasma_surge', name: 'Ionized Violet', visualDesc: 'Electric violet plasma arcs dancing down the shaft.' },
      { id: 'fulgurite', name: 'Fulgurite Glass', visualDesc: 'Glass tube formed from lightning striking desert sand.' },
    ],
  },
  {
    id: 'earth_staff',
    name: 'Earth Staff',
    element: 'Earth',
    levelReq: 15,
    baseDamage: 92,
    attackSpeed: 1.2,
    projectileSpeed: 95,
    critChance: 10,
    elementalPower: 28,
    manaEfficiency: 82,
    specialEffect: 'Tectonic Impact: Attacks knock back enemies and stagger heavy bosses, rupturing ground underneath.',
    evolvedId: 'titan_staff',
    evolvedName: 'Titan Staff',
    evolvedSpecialEffect: 'Continental Shift: Generates seismic shockwaves on impact, raising earthen spikes that impale flanking foes.',
    evolvedDamageBonus: 120,
    description: 'Grown from petrified ancient bedrock and infused with primeval mineral veins.',
    flavorLore: 'Heavier than iron, yet in the hands of a geomancer it swings as effortlessly as a willow branch.',
    howObtained: 'Unearthed from the deep vaults beneath Ancient Ruins.',
    themeColor: '#ca8a04',
    accentGlow: 'rgba(202, 138, 4, 0.45)',
    attackAnimation: 'earthen-boulder',
    availableSkins: [
      { id: 'default', name: 'Granite Monolith', visualDesc: 'Moss-covered carved granite with amber amber veins.' },
      { id: 'jade_dragon', name: 'Imperial Jade', visualDesc: 'Polished emerald jadeite adorned with dragon carvings.' },
      { id: 'meteor_slag', name: 'Stellar Basalt', visualDesc: 'Heavy metallic meteorite stone with magnetic grit.' },
    ],
  },
  {
    id: 'water_staff',
    name: 'Water Staff',
    element: 'Water',
    levelReq: 15,
    baseDamage: 76,
    attackSpeed: 1.7,
    projectileSpeed: 125,
    critChance: 14,
    elementalPower: 26,
    manaEfficiency: 92,
    specialEffect: 'Tidal Flow: Attacks restore 8 Mana on direct hit and cleanse minor debuffs from nearby allies.',
    evolvedId: 'tidal_leviathan_staff',
    evolvedName: 'Tidal Leviathan Staff',
    evolvedSpecialEffect: 'Oceanic Surge: Creates swirling vortex rings that pull enemies together and grant mana regeneration aura.',
    evolvedDamageBonus: 105,
    description: 'Encased in swirling liquid vortex spheres held together by ancient hydromantic currents.',
    flavorLore: 'Water adapts to the shape of whatever vessel it occupies, yet carves canyons into the hardest mountain.',
    howObtained: 'Cleanse the Corrupted Spring in Whispering Forest.',
    themeColor: '#06b6d4',
    accentGlow: 'rgba(6, 182, 212, 0.45)',
    attackAnimation: 'tidal-surge',
    availableSkins: [
      { id: 'default', name: 'Pearl Abyssal', visualDesc: 'Iridescent nacre handle with floating water globules.' },
      { id: 'coral_spire', name: 'Sunken Reef', visualDesc: 'Living crimson coral branches that drip seafoam.' },
      { id: 'deep_trench', name: 'Bioluminescent Abyss', visualDesc: 'Deep indigo casing with glowing angler bulbs.' },
    ],
  },
  {
    id: 'light_staff',
    name: 'Light Staff',
    element: 'Light',
    levelReq: 20,
    baseDamage: 88,
    attackSpeed: 1.8,
    projectileSpeed: 190,
    critChance: 22,
    elementalPower: 32,
    manaEfficiency: 75,
    specialEffect: 'Radiant Dawn: Attacks weaken Shadow enemies by 40% and illuminate shrouded areas in gloom.',
    evolvedId: 'celestial_staff',
    evolvedName: 'Celestial Staff',
    evolvedSpecialEffect: 'Solar Supernova: Blinds all target enemies for 3s, bathing allies in a protective holy shield barrier.',
    evolvedDamageBonus: 125,
    description: 'Carved from ivory sanctum marble and crowned with a halo of concentrated starlight.',
    flavorLore: 'Where darkness spreads fear, the radiant staff projects dawn itself, banishing spectral terrors.',
    howObtained: 'Reach Level 20 and complete the Trial of the Sun in Sky Kingdom.',
    themeColor: '#fbbf24',
    accentGlow: 'rgba(251, 191, 36, 0.5)',
    attackAnimation: 'celestial-lance',
    availableSkins: [
      { id: 'default', name: 'Dawn Halo', visualDesc: 'Gleaming white porcelain staff with rotating brass halo.' },
      { id: 'archangel_wing', name: 'Seraphic Feathers', visualDesc: 'Carved golden wings clasping a prism of pure light.' },
      { id: 'supernova', name: 'Stellar Corona', visualDesc: 'Solar flares continuously pulsing from the focal gem.' },
    ],
  },
  {
    id: 'shadow_staff',
    name: 'Shadow Staff',
    element: 'Shadow',
    levelReq: 25,
    baseDamage: 96,
    attackSpeed: 1.9,
    projectileSpeed: 140,
    critChance: 25,
    elementalPower: 35,
    manaEfficiency: 68,
    specialEffect: 'Umbral Mirage: Attacks have a 25% chance to spawn an autonomous Shadow Clone that mimics spells for 4s.',
    evolvedId: 'void_sovereign_staff',
    evolvedName: 'Void Sovereign Staff',
    evolvedSpecialEffect: 'Shadow Army: Spawns 3 clones on critical strike; player becomes untargetable while clones are active.',
    evolvedDamageBonus: 140,
    description: 'Fashioned from pure solidified darkness harvested at the darkest midnight of Shadow Forest.',
    flavorLore: 'Looking directly at the staff’s tip feels like gazing into an endless chasm that looks back.',
    howObtained: 'Defeat the Nightfall Harvester in Shadow Forest dungeon.',
    themeColor: '#c084fc',
    accentGlow: 'rgba(192, 132, 252, 0.5)',
    attackAnimation: 'arcane-beam',
    availableSkins: [
      { id: 'default', name: 'Umbral Scythe-Head', visualDesc: 'Dark purple void smoke pouring from raven-beak tip.' },
      { id: 'astral_eclipse', name: 'Total Eclipse', visualDesc: 'Black sphere crowned by a razor-thin purple corona.' },
      { id: 'phantom_whisper', name: 'Spectral Shroud', visualDesc: 'Translucent smoke body that flickers between dimensions.' },
    ],
  },
  {
    id: 'ancient_staff',
    name: 'Ancient Staff',
    element: 'Ancient',
    levelReq: 30,
    baseDamage: 110,
    attackSpeed: 1.7,
    projectileSpeed: 150,
    critChance: 20,
    elementalPower: 38,
    manaEfficiency: 88,
    specialEffect: 'Elemental Synthesis: Provides a +25% balanced bonus to ALL elements simultaneously and amplifies combos.',
    evolvedId: 'primordial_chrono_staff',
    evolvedName: 'Primordial Chrono-Staff',
    evolvedSpecialEffect: 'Temporal Overload: Freezes cooldowns for 5 seconds and cycles rotating elemental hyper-beams.',
    evolvedDamageBonus: 160,
    description: 'The legendary staff of the High Council before the Great Fracture, attuned to every planar leyline.',
    flavorLore: 'Its runes do not read in any known modern tongue, yet resonate with the primordial heartbeat of magic.',
    howObtained: 'Complete the Ancient Ruins Grand Sanctum puzzle at Level 30.',
    themeColor: '#2dd4bf',
    accentGlow: 'rgba(45, 212, 191, 0.5)',
    attackAnimation: 'arcane-beam',
    availableSkins: [
      { id: 'default', name: 'Council Prime', visualDesc: 'Ancient brass and jadeite with rotating celestial rings.' },
      { id: 'chrono_gold', name: 'Chrono-Clockwork', visualDesc: 'Working clockwork gears ticking with golden particle trails.' },
      { id: 'relic_carver', name: 'Runic Obelisk', visualDesc: 'Miniature floating obelisk wrapped in turquoise glyphs.' },
    ],
  },
  {
    id: 'void_staff',
    name: 'Void Staff',
    element: 'Void',
    levelReq: 40,
    baseDamage: 145,
    attackSpeed: 2.2,
    projectileSpeed: 160,
    critChance: 30,
    elementalPower: 50,
    manaEfficiency: 60,
    specialEffect: 'Singularity: Collapses reality at the impact zone, dragging all nearby enemies into a crushing gravitational maw.',
    evolvedId: 'singularity_staff',
    evolvedName: 'Singularity Staff',
    evolvedSpecialEffect: 'Event Horizon: Consumes dying enemies to fuel an apocalyptic black hole that explodes for 500% dark magic damage.',
    evolvedDamageBonus: 210,
    description: 'Extremely powerful late-game staff containing an enslaved black hole horizon within a shattered containment ring.',
    flavorLore: 'Forged from the remnants of the Void Mage’s own weapon. Only wizards of supreme mastery can wield it without being torn apart.',
    howObtained: 'Defeat the final boss, The Void Mage, in the Void Arena (Multiplayer or Solo).',
    themeColor: '#ec4899',
    accentGlow: 'rgba(236, 72, 153, 0.6)',
    attackAnimation: 'void-singularity',
    availableSkins: [
      { id: 'default', name: 'Cosmic Singularity', visualDesc: 'A miniature rotating event horizon hovering above obsidian spikes.' },
      { id: 'nebula_rift', name: 'Nebula Rift', visualDesc: 'Swirling pink-and-indigo cosmic dust cloud with dying stars.' },
      { id: 'anti_matter', name: 'Antimatter Core', visualDesc: 'Pulsing negative-color inverted sphere that distorts screen space.' },
    ],
  },
];
