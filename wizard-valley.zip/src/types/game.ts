/**
 * Arcane Citadel - Core Game & Room Types
 */

export type ElementType = 'Fire' | 'Ice' | 'Lightning' | 'Earth' | 'Water' | 'Shadow' | 'Light' | 'Ancient' | 'Void';

export type MaterialKey = 
  | 'magic_dust'
  | 'fire_crystal'
  | 'ice_crystal'
  | 'storm_crystal'
  | 'earth_crystal'
  | 'shadow_fragment'
  | 'light_fragment'
  | 'ancient_core'
  | 'void_crystal';

export interface MaterialMeta {
  key: MaterialKey;
  name: string;
  rarity: 'Common' | 'Uncommon' | 'Rare' | 'Epic' | 'Legendary';
  description: string;
  sources: string[];
  color: string;
}

export interface WeaponItem {
  id: string;
  name: string;
  element: ElementType;
  levelReq: number;
  baseDamage: number;
  attackSpeed: number; // casts per sec
  projectileSpeed: number;
  critChance: number; // percentage
  elementalPower: number; // percentage
  manaEfficiency: number; // percentage
  specialEffect: string;
  evolvedId?: string;
  evolvedName?: string;
  evolvedSpecialEffect?: string;
  evolvedDamageBonus?: number;
  description: string;
  flavorLore: string;
  howObtained: string;
  themeColor: string;
  accentGlow: string;
  attackAnimation: 'arcane-beam' | 'fireball-cascade' | 'glacial-shard' | 'storm-chain' | 'earthen-boulder' | 'void-singularity' | 'celestial-lance' | 'tidal-surge';
  availableSkins: { id: string; name: string; visualDesc: string }[];
}

export interface WeaponOwnedState {
  upgradeLevel: number; // 0 to 10
  isEvolved: boolean;
  selectedSkin: string;
}

export interface WeaponLoadout {
  id: string;
  name: string;
  description: string;
  staffId: string;
  element: ElementType;
  spells: string[];
  accessories: string[];
}

export type PresetType = 'CASUAL' | 'CHALLENGE' | 'CHAOS' | 'CUSTOM';
export type RoomPrivacy = 'PUBLIC' | 'PRIVATE' | 'FRIENDS_ONLY';
export type DifficultyLevel = 'Casual' | 'Normal' | 'Hard' | 'Nightmare' | 'Mythic';
export type GameModeType = 'Co-Op Survival' | 'Boss Rush' | 'Dungeon Crawl' | 'PvP Arena' | 'Elemental Trial' | 'Endless Wave';
export type BossFrequencyType = 'LOW' | 'MEDIUM' | 'HIGH' | 'EXTREME';
export type BalancingMode = 'NORMALIZED' | 'PROGRESSION';

export interface ChaosModifiers {
  fasterEnemies: boolean;
  randomElements: boolean;
  moreBosses: boolean;
  reducedHealing: boolean;
  lowGravity: boolean;
  increasedSpellSpeed: boolean;
  randomEnvironmentalEvents: boolean;
}

export interface RoomSettings {
  roomName: string;
  roomType: RoomPrivacy;
  roomCode: string;
  isLocked: boolean;
  gameMode: GameModeType;
  mapId: string;
  difficulty: DifficultyLevel;
  preset: PresetType;
  maxPlayers: number;
  friendlyFire: boolean;
  teamMode: boolean;
  timeLimitMinutes: number; // 0 = unlimited
  enemyWaves: number; // 0 = endless
  bossFrequency: BossFrequencyType;
  playerRespawns: boolean;
  weaponBalancing: BalancingMode;
  chaosModifiers: ChaosModifiers;
}

export interface RoomPlayer {
  id: string;
  name: string;
  level: number;
  staffId: string;
  staffName: string;
  staffLevel: number;
  isEvolved: boolean;
  isHost: boolean;
  isReady: boolean;
  ping: number;
  roleTitle: string;
  avatarSeed: string;
  avatarColor: string;
}

export interface MapData {
  id: string;
  name: string;
  description: string;
  hazardName: string;
  hazardMechanic: string;
  hazardDetail: string;
  image?: string;
  themeGradient: string;
  accentColor: string;
  recommendedLevel: number;
  ambientEffect: string;
}

export interface PlayerProfile {
  name: string;
  title: string;
  level: number;
  xp: number;
  xpToNext: number;
  mastery: number;
  robes: string;
  hood: string;
  aura: string;
  // Atelier & Customizer properties
  robeColor: string;
  auraColor: string;
  glowIntensity: number;
  hat: string;
  staffVisual: string;
  back: string;
  trail: string;
  unlockedCosmetics: string[];
}

export interface StoryProgression {
  storyProgress: number; // percentage
  completedMissions: string[];
  completedQuests: string[];
  unlockedAreas: string[];
  endlessUnlocked: boolean;
  newGamePlus: number;
}

export interface MultiplayerStats {
  matchesPlayed: number;
  wins: number;
  bossesDefeated: number;
  bestSurvivalWave: number;
  highestScore: number;
  pvpKills: number;
  clutchRevives: number;
}

export interface CollectionsState {
  accessories: string[];
  weaponsDiscovered: string[];
  familiars: string[];
  titles: string[];
  bestiary: string[];
  achievements: string[];
  claimedMilestones: number[];
}

export interface GameSaveData {
  version: number;
  lastSaved: string;
  character: PlayerProfile;
  progression: StoryProgression;
  economy: {
    coins: number;
    materials: Record<MaterialKey, number>;
    elementalCrystals: Record<ElementType, number>;
  };
  weapons: {
    equippedId: string;
    owned: Record<string, WeaponOwnedState>;
    loadouts: WeaponLoadout[];
    activeLoadoutId: string;
  };
  elements: ElementType[];
  spells: string[];
  accessories: string[];
  multiplayerStats: MultiplayerStats;
  collections: CollectionsState;
}
