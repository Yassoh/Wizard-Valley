import React, { createContext, useContext, useState, useEffect } from 'react';
import { GameSaveData, WeaponLoadout, MaterialKey, ElementType } from '../types/game';
import { DEFAULT_SAVE_DATA } from '../data/defaultSave';
import { WEAPONS_CATALOG, getUpgradeCost, getEvolutionCost } from '../data/weaponsData';
import { sounds } from '../utils/audio';

const STORAGE_KEY = 'WIZARD_VALLEY_SAVE_DATA_V2';

interface GameSaveContextType {
  saveData: GameSaveData;
  equippedWeaponData: typeof WEAPONS_CATALOG[0] | undefined;
  upgradeWeapon: (weaponId: string) => { success: boolean; message: string };
  evolveWeapon: (weaponId: string) => { success: boolean; message: string };
  changeSkin: (weaponId: string, skinId: string) => void;
  equipWeapon: (weaponId: string) => void;
  applyLoadout: (loadoutId: string) => void;
  saveNewLoadout: (loadout: Omit<WeaponLoadout, 'id'>) => void;
  claimCollectionReward: (count: number, rewardCoins: number, rewardCores: number) => void;
  recordMultiplayerMatch: (won: boolean, score: number, bossKilled: boolean) => void;
  updateCosmetics: (field: 'robeColor' | 'auraColor' | 'glowIntensity' | 'hat' | 'staffVisual' | 'back' | 'trail', value: any) => void;
  buyCosmetic: (category: 'hat' | 'staffVisual' | 'back' | 'trail', id: string, cost: number) => boolean;
  updateCharacterName: (name: string) => void;
  exportSaveJson: () => string;
  importSaveJson: (json: string) => boolean;
  resetProgress: () => void;
  cheatAddMaterials: () => void; // Dev helper so host can test high-level forging anytime
}

const GameSaveContext = createContext<GameSaveContextType | null>(null);

export const GameSaveProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [saveData, setSaveData] = useState<GameSaveData>(() => {
    if (typeof window !== 'undefined') {
      try {
        const item = localStorage.getItem(STORAGE_KEY);
        if (item) {
          const parsed = JSON.parse(item);
          if (parsed && parsed.version === 2 && parsed.weapons) {
            return parsed;
          }
        }
      } catch (e) {
        console.warn('Failed to load save data from localStorage:', e);
      }
    }
    return DEFAULT_SAVE_DATA;
  });

  // Save to localStorage on every change
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
          ...saveData,
          lastSaved: new Date().toISOString(),
        }));
      } catch (e) {
        console.error('Failed to persist save:', e);
      }
    }
  }, [saveData]);

  const equippedWeaponData = WEAPONS_CATALOG.find(w => w.id === saveData.weapons.equippedId);

  const upgradeWeapon = (weaponId: string) => {
    const catalogWeapon = WEAPONS_CATALOG.find(w => w.id === weaponId);
    if (!catalogWeapon) return { success: false, message: 'Weapon not found in catalog.' };

    const owned = saveData.weapons.owned[weaponId];
    if (!owned) return { success: false, message: 'You do not own this staff yet.' };

    if (owned.upgradeLevel >= 10) {
      return { success: false, message: 'Staff is already at maximum level 10! Seek Arcane Evolution.' };
    }

    const cost = getUpgradeCost(owned.upgradeLevel, catalogWeapon.element);

    if (saveData.economy.coins < cost.coins) {
      return { success: false, message: `Insufficient gold coins (Need ${cost.coins.toLocaleString()}).` };
    }

    if (saveData.economy.materials.magic_dust < cost.magicDust) {
      return { success: false, message: `Insufficient Common Magic Dust (Need ${cost.magicDust}).` };
    }

    for (const c of cost.crystals) {
      const current = saveData.economy.materials[c.key] || 0;
      if (current < c.amount) {
        return { success: false, message: `Insufficient ${c.key.replace(/_/g, ' ')} (Need ${c.amount}).` };
      }
    }

    // Deduct
    const newMaterials = { ...saveData.economy.materials };
    newMaterials.magic_dust -= cost.magicDust;
    for (const c of cost.crystals) {
      newMaterials[c.key] -= c.amount;
    }

    const newUpgradeLevel = owned.upgradeLevel + 1;

    setSaveData(prev => ({
      ...prev,
      economy: {
        ...prev.economy,
        coins: prev.economy.coins - cost.coins,
        materials: newMaterials,
      },
      weapons: {
        ...prev.weapons,
        owned: {
          ...prev.weapons.owned,
          [weaponId]: {
            ...owned,
            upgradeLevel: newUpgradeLevel,
          },
        },
      },
    }));

    sounds.playAnvil();
    setTimeout(() => sounds.playUpgrade(), 150);
    return { success: true, message: `Successfully upgraded ${catalogWeapon.name} to Level ${newUpgradeLevel}/10!` };
  };

  const evolveWeapon = (weaponId: string) => {
    const catalogWeapon = WEAPONS_CATALOG.find(w => w.id === weaponId);
    if (!catalogWeapon || !catalogWeapon.evolvedName) {
      return { success: false, message: 'This weapon cannot evolve.' };
    }

    const owned = saveData.weapons.owned[weaponId];
    if (!owned || owned.upgradeLevel < 10) {
      return { success: false, message: 'Must reach Maximum Upgrade Level 10 before Arcane Evolution!' };
    }

    if (owned.isEvolved) {
      return { success: false, message: 'Weapon has already completed Arcane Evolution.' };
    }

    const cost = getEvolutionCost(catalogWeapon);

    if (saveData.economy.coins < cost.coins) {
      return { success: false, message: `Insufficient gold coins for evolution (Need ${cost.coins.toLocaleString()}).` };
    }

    if (saveData.economy.materials.magic_dust < cost.magicDust) {
      return { success: false, message: `Insufficient Magic Dust (Need ${cost.magicDust}).` };
    }

    for (const c of cost.crystals) {
      const current = saveData.economy.materials[c.key] || 0;
      if (current < c.amount) {
        return { success: false, message: `Missing required ${c.key.replace(/_/g, ' ')} (Need ${c.amount}).` };
      }
    }

    // Deduct materials
    const newMaterials = { ...saveData.economy.materials };
    newMaterials.magic_dust -= cost.magicDust;
    for (const c of cost.crystals) {
      newMaterials[c.key] -= c.amount;
    }

    setSaveData(prev => ({
      ...prev,
      economy: {
        ...prev.economy,
        coins: prev.economy.coins - cost.coins,
        materials: newMaterials,
      },
      weapons: {
        ...prev.weapons,
        owned: {
          ...prev.weapons.owned,
          [weaponId]: {
            ...owned,
            isEvolved: true,
          },
        },
      },
      collections: {
        ...prev.collections,
        achievements: prev.collections.achievements.includes('Arcane Transmutation: Evolve a staff')
          ? prev.collections.achievements
          : [...prev.collections.achievements, 'Arcane Transmutation: Evolve a staff into its Mythic form'],
      },
    }));

    sounds.playAnvil();
    setTimeout(() => sounds.playEvolveFanfare(), 250);
    return { success: true, message: `✨ ARCANE EVOLUTION COMPLETE! Wield the ${catalogWeapon.evolvedName}!` };
  };

  const changeSkin = (weaponId: string, skinId: string) => {
    const owned = saveData.weapons.owned[weaponId];
    if (!owned) return;
    setSaveData(prev => ({
      ...prev,
      weapons: {
        ...prev.weapons,
        owned: {
          ...prev.weapons.owned,
          [weaponId]: {
            ...owned,
            selectedSkin: skinId,
          },
        },
      },
    }));
    sounds.playClick();
  };

  const equipWeapon = (weaponId: string) => {
    if (!saveData.weapons.owned[weaponId]) return;
    setSaveData(prev => ({
      ...prev,
      weapons: {
        ...prev.weapons,
        equippedId: weaponId,
      },
    }));
    sounds.playClick();
  };

  const applyLoadout = (loadoutId: string) => {
    const target = saveData.weapons.loadouts.find(l => l.id === loadoutId);
    if (!target) return;
    setSaveData(prev => ({
      ...prev,
      weapons: {
        ...prev.weapons,
        equippedId: target.staffId,
        activeLoadoutId: target.id,
      },
    }));
    sounds.playUpgrade();
  };

  const saveNewLoadout = (loadout: Omit<WeaponLoadout, 'id'>) => {
    const newId = `loadout_${Date.now()}`;
    const item: WeaponLoadout = { ...loadout, id: newId };
    setSaveData(prev => ({
      ...prev,
      weapons: {
        ...prev.weapons,
        loadouts: [...prev.weapons.loadouts, item],
        activeLoadoutId: newId,
        equippedId: item.staffId,
      },
    }));
    sounds.playClick();
  };

  const claimCollectionReward = (count: number, rewardCoins: number, rewardCores: number) => {
    if (saveData.collections.claimedMilestones.includes(count)) return;
    setSaveData(prev => ({
      ...prev,
      economy: {
        ...prev.economy,
        coins: prev.economy.coins + rewardCoins,
        materials: {
          ...prev.economy.materials,
          ancient_core: prev.economy.materials.ancient_core + rewardCores,
        },
      },
      collections: {
        ...prev.collections,
        claimedMilestones: [...prev.collections.claimedMilestones, count],
      },
    }));
    sounds.playUpgrade();
  };

  const recordMultiplayerMatch = (won: boolean, score: number, bossKilled: boolean) => {
    setSaveData(prev => ({
      ...prev,
      economy: {
        ...prev.economy,
        coins: prev.economy.coins + (won ? 1500 : 500),
        materials: {
          ...prev.economy.materials,
          magic_dust: prev.economy.materials.magic_dust + (won ? 25 : 10),
          ancient_core: bossKilled ? prev.economy.materials.ancient_core + 1 : prev.economy.materials.ancient_core,
        },
      },
      multiplayerStats: {
        ...prev.multiplayerStats,
        matchesPlayed: prev.multiplayerStats.matchesPlayed + 1,
        wins: won ? prev.multiplayerStats.wins + 1 : prev.multiplayerStats.wins,
        bossesDefeated: bossKilled ? prev.multiplayerStats.bossesDefeated + 1 : prev.multiplayerStats.bossesDefeated,
        highestScore: Math.max(prev.multiplayerStats.highestScore, score),
      },
    }));
  };

  const exportSaveJson = () => {
    return JSON.stringify(saveData, null, 2);
  };

  const importSaveJson = (json: string): boolean => {
    try {
      const parsed = JSON.parse(json);
      if (parsed && parsed.weapons && parsed.character && parsed.economy) {
        setSaveData(parsed);
        sounds.playUpgrade();
        return true;
      }
    } catch (e) {
      console.error(e);
    }
    return false;
  };

  const updateCosmetics = (field: 'robeColor' | 'auraColor' | 'glowIntensity' | 'hat' | 'staffVisual' | 'back' | 'trail', value: any) => {
    setSaveData(prev => ({
      ...prev,
      character: {
        ...prev.character,
        [field]: value,
      },
    }));
  };

  const buyCosmetic = (category: 'hat' | 'staffVisual' | 'back' | 'trail', id: string, cost: number): boolean => {
    if (saveData.economy.coins < cost) return false;

    setSaveData(prev => ({
      ...prev,
      economy: {
        ...prev.economy,
        coins: prev.economy.coins - cost,
      },
      character: {
        ...prev.character,
        [category]: id,
        unlockedCosmetics: prev.character.unlockedCosmetics.includes(id)
          ? prev.character.unlockedCosmetics
          : [...prev.character.unlockedCosmetics, id],
      },
    }));
    sounds.playUpgrade();
    return true;
  };

  const updateCharacterName = (name: string) => {
    if (!name.trim()) return;
    setSaveData(prev => ({
      ...prev,
      character: {
        ...prev.character,
        name: name.trim(),
      },
    }));
  };

  const resetProgress = () => {
    try {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem('ARCANE_CITADEL_SAVE_DATA_V1');
    } catch (e) {
      // ignore
    }
    setSaveData(DEFAULT_SAVE_DATA);
    sounds.playClick();
  };

  const cheatAddMaterials = () => {
    setSaveData(prev => ({
      ...prev,
      economy: {
        coins: prev.economy.coins + 25000,
        materials: {
          magic_dust: prev.economy.materials.magic_dust + 200,
          fire_crystal: prev.economy.materials.fire_crystal + 10,
          ice_crystal: prev.economy.materials.ice_crystal + 10,
          storm_crystal: prev.economy.materials.storm_crystal + 10,
          earth_crystal: prev.economy.materials.earth_crystal + 10,
          shadow_fragment: prev.economy.materials.shadow_fragment + 10,
          light_fragment: prev.economy.materials.light_fragment + 10,
          ancient_core: prev.economy.materials.ancient_core + 5,
          void_crystal: prev.economy.materials.void_crystal + 4,
        },
        elementalCrystals: { ...prev.economy.elementalCrystals },
      },
    }));
    sounds.playUpgrade();
  };

  return (
    <GameSaveContext.Provider
      value={{
        saveData,
        equippedWeaponData,
        upgradeWeapon,
        evolveWeapon,
        changeSkin,
        equipWeapon,
        applyLoadout,
        saveNewLoadout,
        claimCollectionReward,
        recordMultiplayerMatch,
        updateCosmetics,
        buyCosmetic,
        updateCharacterName,
        exportSaveJson,
        importSaveJson,
        resetProgress,
        cheatAddMaterials,
      }}
    >
      {children}
    </GameSaveContext.Provider>
  );
};

export const useGameSave = () => {
  const context = useContext(GameSaveContext);
  if (!context) throw new Error('useGameSave must be used within a GameSaveProvider');
  return context;
};
